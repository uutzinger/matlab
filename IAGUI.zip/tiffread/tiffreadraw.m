function s = tiffreadraw(filename)

% tiffread, version 2.7 January 28, 2009
%
% stack = tiffread(filename);
% was waste of time is much slower than original tiffread
% for i=1:numimages; imread(tifffile, 'Index', i); end
% is about 2 times faster
%

%without argument, we ask the user to choose a file:
if nargin < 1
    [filename, pathname] = uigetfile('*.tif;*.stk;*.lsm', 'select image file');
    filename = [ pathname, filename ];
end

if  isempty(findstr(filename,'.'))
    filename = [filename,'.tif'];
end

t = Tiff(filename,'r');
if t == -1
    stkname = strrep(filename, '.tif', '.stk');
    t = Tiff(stkname,'r');
    if TIF.file == -1
        error(['File "',filename,'" not found.']);
    else
        filename = stkname;
    end
end

i=1;
while 1;
    clear IMG;
    IMG.filename =  filename;
    % read Tags
    tagNames = t.getTagNames();
    for j=1:length(tagNames);
        try eval(['IMG.' tagNames{j} '=t.getTag(tagNames{j});']); end
    end
    % read image and split color channels
    tmp = t.read();
    for c=1:size(tmp,3)
        IMG.data{c}=tmp(:,:,c);
    end
    s(i) = IMG; i=i+1;
    if ~t.lastDirectory(); t.nextDirectory(); else break; end;
end
t.close();


