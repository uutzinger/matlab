function stack = omeread(filename)
% omeread, version 0.1 2009
%
% stack = omeread;
% stack = omeread(filename);

%without argument, we ask the user to choose a file:
if nargin < 1
    [filename, pathname] = uigetfile('*.tif;*.stk;*.lsm', 'select image file');
    filename = [ pathname, filename ];
end

data = tiffread(filename); % read tiff file

if isfield(data, 'ome')
    % checkif xml is already written to a file
    % build xml filename
    loc=findstr(filename, '.ome');
    xmlfilename=[filename(1:loc(end)),'ome.xml'];
    
    OME.file = fopen(xmlfilename,'r');
    if OME.file == -1
       OME.file = fopen(xmlfilename,'w');
       if OME.file ~= -1
           oe=findstr(data.ome,'</OME>')
           os=findstr(data.ome,'<?xml')
           fwrite(OME.file, data.ome(os:oe+5));
           fclose(OME.file);
           OME.meas = xml_read(xmlfilename);
           data.ome = omeattribs(OME);
       else
          error(['File "',xmlfilename,'" could not be opened.']);
          break;
       end
    else
        % file arelady exists 
        OME.meas = xml_read(xmlfilename);
       data.ome = omeattribs(OME);
    end
else
    error ('% no ome extension found')
end


%
% Now parse through fields and create file list.
% Then load each file
% Add each file to stack structure:
% stack(timepoint,Z-location).data{Channel#}(x,y)
%

%Somehow need this to combined data correctly
data.ome.Imageinfo.DimensionOrder

for i=1:size(data.ome.TiffData,2)

    try
    temp = tiffread(data.ome.TiffData(i).FileName)
    % data.ome.TiffData.UUID 

    switch data.ome.Imageinfo.DimensionOrder
        case 'XYZTC'
            % not supported
        case 'XYZCT'
           % standard LVBT with Z in tiff file
           % stack(timepoint,Z).data{channel}(x,y)
           T=data.ome.TiffData(i).FirstT
           Z=data.ome.TiffData(i).FirstZ
           C=data.ome.TiffData(i).FirstC
           % Z should be zero
           % C might not be present
           stack(T,Zrange).data(C) = temp(1,Zrange).data;
        case 'XYCZT'
            % standard LVBT with C in tiff file
        otherwise
    end
    catch
        was not able to read file or combine data, still return what we have
    end
   
end % read all files
    
end % OMEread


function attributes = omeattribs(OME)
% Celan up xml structure and take only waht we need.
%

% OME.meas.Experimenter
% contains info on who took the image
attributes.Experimenter = OME.meas.Experimenter;
rmfield(attributes.Experimenter, 'ATTRIBUTE')

% OME.meas.Image.CreationDate (year-month-dayThour:min:sec)
attributes.CreationDate = OME.meas.Image.CreationDate;
attributes.Description = OME.meas.ImageDescription;

% OME.meas.Image.Pixels.ATTRIBUTE
% contains
% BigEndian: 'false'
% DimensionOrder: 'XYZTC', LVBT: XYZCT oder XYCZT
% ID: 'Pixels:53D5910A-E236-41BC-B34F-792A60A40D38'
% PhysicalSizeX: 0.3906
% PhysicalSizeY: 0.3906
% PhysicalSizeZ: 0.9903
% PixelType: 'uint16'
% SizeC: 1
% SizeT: 148
% SizeX: 1024
% SizeY: 1024
% SizeZ: 103
attributes.ImageInfo = OME.meas.Image.Pixels.ATTRIBUTE;

% OME.meas.Image.Pixels.TIFFData containts a number of structures ,
% mostlikely amount strucrers is sizeT * SizeC and is amount of filenames
%
% In those structures one can find
%
% OME.meas.Image.Pixels.TiffData(1).UUID.CONTENT: fileid
% OME.meas.Image.Pixels.TiffData(1).UUID.ATTRIBUTE.FileName
% OME.meas.Image.Pixels.TiffData(1).ATTRIBUTE.FirstT might be needed for order
% OME.meas.Image.Pixels.TiffData(1).ATTRIBUTE.FirstZ might be needed for
% order, is 0 if complete stack is done first.
% OME.meas.Image.Pixels.TiffData(1).ATTRIBUTE.FirstC might be needed for order
attributes.TiffData.UUID     = OME.meas.Image.Pixels.TiffData.UUID.CONTENT;
attributes.TiffData.FileName = OME.meas.Image.Pixels.TiffData.UUID.ATTRIBUTE;
attributes.TiffData.FirstT   = OME.meas.Image.Pixels.TiffData.ATTRIBUTE.FirstT;
attributes.TiffData.FirstC   = OME.meas.Image.Pixels.TiffData.ATTRIBUTE.FirstC;
attributes.TiffData.FirstZ   = OME.meas.Image.Pixels.TiffData.ATTRIBUTE.FirstZ;

end


Need to copy C:\IAGUI\tiffread.m to \\spxdata\spxlab\software\tiffread

