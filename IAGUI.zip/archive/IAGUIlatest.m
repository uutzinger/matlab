function varargout = IAGUIlatest(varargin)
%   Image Analysis GUI is a MATLAB GUI for the analysis of tiff files.   
%   
%   Navigate the directory and click on the file you want to open.
%   If the files is an image stack the preview wil allow you to navigate to
%   the image of interest.
%   An image can consists of many channels. When an image is slected all
%   channels are loaded. The Previewer can display up to 3 channels,
%   assinging them r,g,b.
%
%   Histrogram manipulation & filter:
%   Histogram manupulation allows changing the dynamic range of one channel
%   at a time. For some images it is helpful to apply a Wiener de-noising
%   filter after adjusting the dynamic range.
%   Reset Image and Reset Channel will reload the data if the histrogram
%   manipulation or the filter was not satisfactory.
%   Adjusting the dynamic range is useful to remove detector background.
%   When adjusting the image channel two separate windows are opened. One
%   is the preview and the other the control. It is possible to adjust the
%   range to 98% of the max-min which removed outlayers and background.
%   To copy data back to the main application the preview window apply data
%   will need to be selected. The control window's apply will only update
%   the
%   histrogram.
%
%   Display Channels:
%   Each channel measurementcan be color coded or not shown. Colors will be mixed to
%   gether.
%   A 50 micorn scale bar can be added to the display. If there was no LSM
%   file loaded, there will be no Pixel Scale and one needs to add it 
%   manually by entering the with of a pixel in micron. The scale bar can
%   be black or white and its transparencey can be adjusted.
%
%   Saving of images:
%   Images can be saved. A new window is opened and if the verctor field
%   was anabled it will include it. The images is saved using Matlab
%   options of saving a figure.
%
%   Analysis:
%   One can extract intensities from ROIs and Profiles. One can also 
%   calculate the average direction based on gradients. Previously selected
%   ROIs and lines can be selected.
%   The ROI, Line and Vessel direction can be indicated on the image.
%   Points are selected by mouse click and the selection is terminated with
%   right mouse click. 
%
%   Vector analysis:  
%   Blocksize is the width of the analysis windows, sigma are the 
%   smoothing filter width and the thresholds and reliability levels limit
%   included values.
%   The correct analysis channel will need to be selected. 
%
%   Intensity analysis:
%   Histograms inside ROIs can be generated. A profile has a width and the
%   intensity is average over that width.
%
%   Data saving:
%   Data of one ROI, one profile and one vessel direction can be saved as 
%   one measurement. Measurements can be appended and brosed through.
%   4 different measurement cateories can be selected for easier 
%   identification during later analysis. Measurements are loaded when
%   the images files are loaded if they are present in the diretory. They
%   have the same name as the image files but end with mat. Documentation
%   on their structure is available separately. They contain beside
%   averages also the data of the analysis.
%
%   Filter and dynamic range adjustments should be kept the same for each
%   image if an analysis is conducted.
%
%   Future code developments:
%   -Hypeer intense data removal
%   -Autoamted cell extraction
%   -Image correlation spectrosocpy
%   -Image segmentation based on simlar areas
%   -New concpets for automated processing of stacks and series
%
%   Code written by: Stylianos Andreou
%                    Laboratory inTissue Spectroscopy and Bio-Signatures
%                    University of Arizona � 2006     
%
%   Reworked by Michalis Michaelides September 2007 
%     - Added capability for more than 3 channels
%     - Added better functionality to interface
%     - Some code optimization to run faster
%     - Fixed code for generating profile to select the correct points
%     - Added a profile graph on the interface
%     - Changed the data structure that will be saved
%     - Added option to change channel color
%     - Added 50um Bar display
%     - Added option to adjust channel contrast 
%     - Added save image function to save the image displayed
%     - Added ROI histogram
%     - ROI now applies to all channels for intensity values
%     - Line Profile applies to all channels
%     
%    email:andreou@email.arizona.edu
%          mmichael@email.arizona.edu
%
%   Bugfixes & Improvements by Urs Utzinger 
%   2008 
%     - Added capability for moving through stack 5 steps a time
%     - Repaired ROI function, mask was not calculate properly
%     - Repaired Profile function, linewidth points were not caluculate
%       properly
%     - Added capability of reusing ROI, Profile and Vessel Orientation
%     - Histogram of directions.
%     - Tiff reading
%   2009
%     - added 16 bit functionality
%     - Reorganized order of functions and routines for better code management 
%     - Integrated ICS
%     - Working on: OME TIF read, expand handling of multiple time points
%
% See also: IAGUIlatest
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%ActiveX COntrol Error is occuring below in gui_mainfcn. Do not kno whow to make it go away

%%
% Last Modified by GUIDE v2.5 20-Aug-2009 09:57:25

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @IAGUIlatest_OpeningFcn, ...
                   'gui_OutputFcn',  @IAGUIlatest_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT
end

%% --- Executes just before IAGUIlatest is made visible.
function IAGUIlatest_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to IAGUIlatest (see VARARGIN)
% Choose default command line output for IAGUIlatest
handles.output = hObject;
% Update handles structure
handles.Vectors =[]; %initialize the pointer
handles.ICSResults = [];
handles.VesselLineHandle =[];
handles.ProfileLineHandle = [];
handles.ROILineHandle = [];
handles.VesselLinePreHandle =[];
handles.ProfileLinePreHandle =[];
handles.ROILinePreHandle =[];
handles.Bar200umHandle = [];
handles.previous_xpts_Profile=[];
handles.previous_xpts_Vessel=[];
handles.previousROI_x=[];
set(handles.delete,'Enable','off');
set(handles.popMeasChan,'Enable','off');
set(handles.ICSEnable,'Enable','off');
set(handles.VectorEnable,'Enable','off');

handles.ColorDef = [ 0 0 0;...%none
                     1 0 0;...%Red
                     1 0 1;...%Pink
                     0 0 1;...%Blue
                     0 1 1;...%Teal
                     0 1 0;...%Green
                     1 1 0;...%Yellow
                     1 1 1;];  %White
guidata(hObject, handles);
%and invoke the function to update file list
actxBrowser = COM.mwxpccontrolsx2x7x2_PathChooserCtrl; %temporarily assign the handle
activex9_Change(actxBrowser,[],handles);   
% load_filelist(handles);
% UIWAIT makes IAGUIlatest wait for user response (see UIRESUME)
% uiwait(handles.figure1);
end
%% --- Executes during object creation, after setting all properties.
function analyze_CreateFcn(hObject, eventdata, handles)
% hObject    handle to analyze (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
set(hObject,'Enable','off');
end
%% --- Outputs from this function are returned to the command line; No output at this time
function varargout = IAGUIlatest_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
end

%%
% *************************************************************************
%      FUNCTION SECTIONS
% *************************************************************************
%
% 1 Create selectabel file list
% 2 Read Image Stack and associated previous measurements, updates GUI,
% runs main processing at end
% 3 Main processing function
% 4 Navigate through stack and update preview 
% 5 Select ROI, Profiles, Vessel Orientation
% 6 Measurement, Create, Save, Delete, Display
% 7 Analyze, Vector Analysis
% 8 Window Menu
% 9 Image display adjustments; Color mixing, chanel intensity,
% 10 Image data contrast adjustment, Wiener filter
% 11 Scale Bar
% 12 Save Imagee
% 13 Miscalleneous Matlab Functions
%
% Important Variables
% Image data: handles.ImgChannel, used for ROI, Analysis 
%             handles.OrigImgChannel, used to keep backup of unaltered data
% Vector data: handles.Vectors
% 
% Image adjustments (histogram & Wiener filter) are conducted on 
% handles.ImgChannel (modifies data, will affect analysis) 
% Cannel intensity & Scale Bar & vector plot is added in display routines
% not on image data

%% 1 FILE list, directory browsing, read file
% --- PathChooser
function activex9_Change(hObject, eventdata, handles)
% hObject    handle to activex (see GCBO)
% eventdata  structure with parameters passed to COM event listener
% handles    structure with handles and user data (see GUIDATA)
    handles.path=hObject.Path;
    guidata(handles.figure1,handles);
    load_filelist(handles);
end
% --- Read the current directory and sort the names (either LSM or Tiff)
function load_filelist(handles)
    dir_struct = [dir([handles.path '\*.lsm']);dir([handles.path '\*.tif']);dir([handles.path '\*.tiff'])];
    set(handles.lsmlist,'String',{dir_struct.name}','Value',1);
end
% --- Create file list box properties
function lsmlist_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end
end
% --- Handle file selection
function lsmlist_Callback(hObject, eventdata, handles)
    % check for double click in the list box
    % get(handles.figure1,'SelectionType');
    if strcmp(get(handles.figure1,'SelectionType'),'open')
        %if true(double click) run the main code
        % should open display stating reading 
        readlsmfile(handles); % Read and display the image
    end
end

%% 2 Read tiff file
function readlsmfile(handles)
    %get the filename of the selected lsm file
    SelectedIndex = get(handles.lsmlist,'Value');
    FileList = get(handles.lsmlist,'String');	
    handles.filename = FileList{SelectedIndex};
    cd (handles.path);
    %%
    %read the images from the lsm or tiff file file
    hmsg=msgbox('Loading...','Loading File');
    im=[];
    im = tiffread([handles.path '\' FileList{SelectedIndex}]);
    % if this was LSM file we need to check for preview images that were
    % introduced at later versions of LSM software
    % We will neede to solve this differently because OME read might result
    % in more complext file structure
    if size(im,2) >1
        % fix LSM preview issues
        if im(1).width~=im(2).width;
            im_preview=im(2:2:size(im,2));
            im=im(1:2:size(im,2));
        end
    end
    nbImages=size(im,2);
    close(hmsg);
    
    % Obsolete code:
    % read LSM calibration data
    % this could be taken directly from the stack and should be updated
    % when ever a new image is loaded into the analysis module.
    % the lsminfo routine should be changed to an lsm parser and removed
    % from the code.
    %
    % LSMinf.ScanInfo.SMAPLE_SPACING is same ans lsm.VoxelSize except voxesl size is in meters and spacing is in microns
    %
    %
    % if ~isempty(findstr(FileList{SelectedIndex},'.lsm'))
    %    [handles.LSMinf handles.SCANinf handles.IMinf] = ...
    %    lsminfo([handles.path '\' FileList{SelectedIndex}]);
    % else
    %    % is not an LSM file
    %    handles.LSMinf=[];
    %    handles.LSMinf.ScanInfo.SAMPLE_SPACING=1;
    %    handles.SCANinf=[];
    %    handles.IMinf=[];
    % end
    % update pixel spaceing information, can be edited on front panel also
    % set(handles.edtPixSpace,'String',handles.LSMinf.ScanInfo.SAMPLE_SPACING);
    % End Obsolte Code
    
    %%
    % Set Physical Image Size Calibration Information
    %
    if isfield(im(1,1), 'lsm')
        [handles.LSMinf] = im(1,1).lsm; % assuming all files have square pixels and each image has same size.
    else
        % is not an LSM file
        handles.LSMinf=[];
        handles.LSMinf.VoxelSizeX=1;
        handles.SCANinf=[];
        handles.IMinf=[];
    end
    set(handles.edtPixSpace,'String',num2str(handles.LSMinf.VoxelSizeX*1e6));
 
    %%
    % Update Select Image Buttons
    if (nbImages>1)
        set(handles.next,'Enable','on');
        set(handles.next_fine,'Enable','on');
    else
        set(handles.next,'Enable','off');
        set(handles.next_fine,'Enable','off');
    end
    set(handles.prev,'Enable','off');
    set(handles.prev_fine,'Enable','off');
    set(handles.delete,'Enable','off');
    %%
    %check if previous analysis data exist for that image file
    loc=findstr(handles.filename, '.');
    filename=[handles.filename(1:loc(end)-1) '.mat'];
    dir_struct = dir([handles.path '\' filename]);
    %if true load the data
    if((isempty(dir_struct))==0)
        Data=load(filename);
        handles.Data=Data.Data;
        %if file exists but all measurements were previously deleted...
        if (isempty(handles.Data(1).Meas))
            handles.Data.Meas = EmptyMeasStructure(length(im(1).data));
        end
    else
        for k=1:nbImages
            handles.Data(k).Meas = EmptyMeasStructure(length(im(1).data));
        end
    end
    %%
    % Need to clear handles current measurement, not sure but seems to work
    handles.CurMeas=EmptyMeasStructure(length(im(1).data));
    
    try
        if ~(isempty(handles.Vectors)) %Reset the handles for the vector field if they exist
             delete(handles.Vectors);
        end
    catch me
        warning('Have orphaned handles.Vectors. Better restart program.')
    end
        handles.Vectors=[];
    % Do not have plot handles but need to celar ICSResults also
    handles.ICSResults=[];
    
    %%
    %Read the images from the LSM file
    handles.OrigImgChannel=[];
    for i =1:nbImages
        for k=1:length(im(1).data)%Check the number of channels in the first image
                                  %This assumes that the number of
                                  %channels is the same for all images
            handles.OrigImgChannel{i,k} = [im(i).data{k}, [] ];
        end
    end

    %  length(im(1).data)
    handles.ImgChannel =[];
    handles.ImgChannel = handles.OrigImgChannel;
    set(handles.lstPreviewChan, 'String', []);
    %Clear the preview channels list and then populate it
    for lstPop=1:length(im(1).data)
        TempLst = get(handles.lstPreviewChan,'String');
        set(handles.lstPreviewChan, 'String', [TempLst; ['Channel ',num2str(lstPop)]]);
        set(handles.lstDisplayChan, 'String', [TempLst; ['Channel ',num2str(lstPop)]]);        
        set(handles.popHistBackChan, 'String', [TempLst; ['Channel ',num2str(lstPop)]]);
        set(handles.popAnalysisChan, 'String', [TempLst; ['Channel ',num2str(lstPop)]]);
        set(handles.popMeasChan, 'String', [TempLst; ['Channel ',num2str(lstPop)]]);
    end
   
    set(handles.lstPreviewChan, 'Value',1);
    set(handles.lstDisplayChan, 'Value',1);
    set(handles.popHistBackChan, 'Value',1);
    set(handles.popAnalysisChan, 'Value',1); 
    set(handles.popMeasChan,'Value',1)
    set(handles.grpColor,'Visible','on');
    set(handles.rdoWhite,'Value',1);
    set(handles.chkShow200um,'Value',0);

    handles.ChanCol = ones(1,length(im(1).data)); %initialize display color to none
    handles.ChanCol(1) = 8; %except for the first channel which is going to be White
    handles.ChanIntensity = ones(1,length(im(1).data)); %All Channels at 100% intensity
    
    clear TempLst
    clear im
    
    %initialize assosiate variales
    handles.nbImages=nbImages;
    handles.CurImgNo=1;
    handles.l=0;
    
    set(handles.next2,'Enable','off');
    set(handles.prev2,'Enable','off');
    
    set(handles.ICSEnable,'Enable','on');
    set(handles.VectorEnable,'Enable','on');
    
    %display the selected lsm file

    guidata(handles.figure1,handles);
    handles = mainprocessing(handles);

end
   
%% 3 Prepare Processing Function
% --- Populate Preview and Analysis Window; Show measurement ROI & lines; Show Channel Histrogram 
function handles = mainprocessing(handles)    
% Populate Preview and Analysis Window
    %%
    % --- Preview Image
    % Display the images from the LSM file
    RGBImage = double(zeros([size(handles.OrigImgChannel{1,1}),3])); %initialize matrix to accept RGB values
    ColorIndex=0;
    switch class(handles.OrigImgChannel{handles.CurImgNo,1})
        case 'uint8'
            sl=255;
        case 'uint16'
            sl=65535;
        otherwise
            warning('unsupported bit depth')
            sl=255;
    end
    for DispIndx = get(handles.lstPreviewChan, 'Value') %Assumes that max of 3 channels are selected
        ColorIndex = ColorIndex + 1;
        % scale by maximum
        % sl=max(max(handles.OrigImgChannel{handles.CurImgNo,DispIndx}));
        % build image
        % RGBImage(:,:,ColorIndex) = double((handles.OrigImgChannel{handles.CurImgNo,DispIndx})./sl);
        RGBImage(:,:,ColorIndex) = double(imadjust(handles.OrigImgChannel{handles.CurImgNo,DispIndx}))./sl;
    end
    %Show Preview image
    axes(handles.lsmimg);
    handles = cla_lsmimg(handles); 
    imshow(RGBImage);
    %Display the stack size and current image number
    set(handles.totalimages, 'String', ['Img.', num2str(handles.CurImgNo), '/', num2str(handles.nbImages)]);
    
    %%
    % --- Analysis Image
    displayimage=GetDisplayImg(handles);
    axes(handles.procimg);
    handles = cla_procimg(handles);
    handles.DisplayImgHandle = imshow(displayimage);

    %%
    % --- Measurements
    % Update measured data display, seems to have issues
    if (isempty(handles.Data(handles.CurImgNo).Meas(1).Channel))
       handles.l=0;
       handles.showid=0;
       handles = ShowMeasurement(handles, EmptyMeasStructure(length(handles.ImgChannel(handles.CurImgNo,:))), handles.showid, handles.l);
    else
       handles.l=length(handles.Data(handles.CurImgNo).Meas);
       handles.showid=1;
       set(handles.delete,'Enable','on');
       if(handles.l>1)
       set(handles.next2,'Enable','on');
       end
       handles = ShowMeasurement(handles, handles.Data(handles.CurImgNo).Meas(handles.showid), handles.showid, handles.l);
    end
   
    %%
    % -- Activate Analysis Buttons
    set(handles.analyze,'Enable','on');
    set(handles.Line,'Enable','on');
    set(handles.vessel,'Enable','on');

    %%
    % --- Update Intensity Histogram
    popHistBackChan_Callback(handles.popHistBackChan, [], handles);

    %%
    % --- Initialize the current measurement on the image
    handles.CurMeas = EmptyMeasStructure(length(handles.ImgChannel(handles.CurImgNo,:)));
    set(handles.save,'Enable','off');
    if (~isempty(handles.ProfileLineHandle))
        delete(handles.ProfileLineHandle);
        handles.ProfileLineHandle=[];
    end
    if (~isempty(handles.VesselLineHandle))
        delete(handles.VesselLineHandle);
        handles.VesselLineHandle=[];
    end
    axes(handles.axeProfile);
    cla;
    plot(0,0)
    set(handles.pnlProfile,'Title','Profile');
    
    % handlesOUT=handles;
    % needs this to update GUI with handles that were changed inside this
    % routine.
    guidata(handles.figure1,handles);   
end

%% 4 Navigate through stack and show previews
% --- Forward + 5.
function next_Callback(hObject, eventdata, handles)
    set(handles.prev_fine,'Enable','off');
    set(handles.next_fine,'Enable','off');
    set(handles.prev,'Enable','off');
    set(handles.next,'Enable','off');
    handles.CurImgNo=handles.CurImgNo+5;
    if (handles.CurImgNo>=handles.nbImages)
         handles.CurImgNo=handles.nbImages;
         set(hObject,'Enable','off');
    else
         set(hObject,'Enable','on');
    end
    if (~isempty(handles.Vectors))
        delete(handles.Vectors);
        handles.Vectors=[];
    end
    if (~isempty(handles.ICSResults))
        delete(handles.ICSResults);
        handles.ICSResults=[];
    end
    if (~isempty(handles.ProfileLineHandle))
        delete(handles.ProfileLineHandle);
        handles.ProfileLineHandle = [];
    end
    if (~isempty(handles.VesselLineHandle))
        delete(handles.VesselLineHandle);
        handles.VesselLineHandle = [];
    end
    if (~isempty(handles.ROILineHandle))
        delete(handles.ROILineHandle);
        handles.ROILineHandle = [];
    end
    guidata(handles.figure1,handles);
    handles = mainprocessing(handles);
    if (handles.CurImgNo==handles.nbImages)
        set(handles.prev,'Enable','on');    
        set(handles.prev_fine,'Enable','on');    
        set(handles.next,'Enable','off');    
        set(handles.next_fine,'Enable','off');    
    else
        set(handles.prev,'Enable','on');    
        set(handles.prev_fine,'Enable','on');    
        set(handles.next,'Enable','on');    
        set(handles.next_fine,'Enable','on');    
    end
    guidata(handles.figure1,handles);
end
function next_CreateFcn(hObject, eventdata, handles)
% hObject    handle to next (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

    set(hObject,'Enable','off');
end
% --- Backward -5.
function prev_Callback(hObject, eventdata, handles)
    set(handles.prev_fine,'Enable','off');
    set(handles.next_fine,'Enable','off');
    set(handles.prev,'Enable','off');
    set(handles.next,'Enable','off');
    handles.CurImgNo=handles.CurImgNo-5;
    if (handles.CurImgNo<=1)
       handles.CurImgNo=1;
       set(hObject,'Enable','off');
    else
       set(hObject,'Enable','on');
    end
    if (~isempty(handles.Vectors))
        delete(handles.Vectors);
        handles.Vectors=[];
    end
    if (~isempty(handles.ICSResults))
        delete(handles.ICSResults);
        handles.ICSResults=[];
    end
    if (~isempty(handles.ProfileLineHandle))
        delete(handles.ProfileLineHandle);
        handles.ProfileLineHandle = [];
    end
    if (~isempty(handles.VesselLineHandle))
        delete(handles.VesselLineHandle);
        handles.VesselLineHandle = [];
    end
    if (~isempty(handles.ROILineHandle))
        delete(handles.ROILineHandle);
        handles.ROILineHandle = [];
    end
    guidata(handles.figure1,handles);
    handles = mainprocessing(handles);
    if (handles.CurImgNo==1)
        set(handles.next_fine,'Enable','on');
        set(handles.next,'Enable','on');
        set(handles.prev_fine,'Enable','off');
        set(handles.prev,'Enable','off');
    else
        set(handles.next_fine,'Enable','on');
        set(handles.next,'Enable','on');
        set(handles.prev_fine,'Enable','on');
        set(handles.prev,'Enable','on');
    end
    guidata(handles.figure1,handles);
end
function prev_CreateFcn(hObject, eventdata, handles)
% hObject    handle to prev (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

    set(hObject,'Enable','off');
end
% --- Forward +1.
function prev_fine_Callback(hObject, eventdata, handles)
% hObject    handle to prev_fine (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    set(handles.prev_fine,'Enable','off');
    set(handles.next_fine,'Enable','off');
    set(handles.prev,'Enable','off');
    set(handles.next,'Enable','off');
    handles.CurImgNo=handles.CurImgNo-1;
    if (handles.CurImgNo<=1)
       handles.CurImgNo=1;
       set(hObject,'Enable','off');
    else
       set(hObject,'Enable','on');
    end
    if (~isempty(handles.Vectors))
        delete(handles.Vectors);
        handles.Vectors=[];
    end
    if (~isempty(handles.ICSResults))
        delete(handles.ICSResults);
        handles.ICSResults=[];
    end
    if (~isempty(handles.ProfileLineHandle))
        delete(handles.ProfileLineHandle);
        handles.ProfileLineHandle = [];
    end
    if (~isempty(handles.VesselLineHandle))
        delete(handles.VesselLineHandle);
        handles.VesselLineHandle = [];
    end
    if (~isempty(handles.ROILineHandle))
        delete(handles.ROILineHandle);
        handles.ROILineHandle = [];
    end
    guidata(handles.figure1,handles);
    handles = mainprocessing(handles);
    if (handles.CurImgNo==1)
        set(handles.next_fine,'Enable','on');
        set(handles.next,'Enable','on');
        set(handles.prev_fine,'Enable','off');
        set(handles.prev,'Enable','off');
    else
        set(handles.next_fine,'Enable','on');
        set(handles.next,'Enable','on');
        set(handles.prev_fine,'Enable','on');
        set(handles.prev,'Enable','on');
    end
    guidata(handles.figure1,handles);
end
% --- Bachward -1.
function next_fine_Callback(hObject, eventdata, handles)
% hObject    handle to next_fine (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    set(handles.prev_fine,'Enable','off');
    set(handles.next_fine,'Enable','off');
    set(handles.prev,'Enable','off');
    set(handles.next,'Enable','off');
    handles.CurImgNo=handles.CurImgNo+1;
    if (handles.CurImgNo>=handles.nbImages)
        handles.CurImgNo=handles.nbImages;
        set(hObject,'Enable','off');
    else
        set(hObject,'Enable','on');
    end
    if (~isempty(handles.Vectors))
        delete(handles.Vectors);
        handles.Vectors=[];
    end
    if (~isempty(handles.ICSResults))
        delete(handles.ICSResults);
        handles.ICSResults=[];
    end
    if (~isempty(handles.ProfileLineHandle))
        delete(handles.ProfileLineHandle);
        handles.ProfileLineHandle = [];
    end
    if (~isempty(handles.VesselLineHandle))
        delete(handles.VesselLineHandle);
        handles.VesselLineHandle = [];
    end
    if (~isempty(handles.ROILineHandle))
        delete(handles.ROILineHandle);
        handles.ROILineHandle = [];
    end
    guidata(handles.figure1,handles);
    handles = mainprocessing(handles);
    if (handles.CurImgNo==handles.nbImages)
        set(handles.next_fine,'Enable','off');
        set(handles.next,'Enable','off');
        set(handles.prev_fine,'Enable','on');
        set(handles.prev,'Enable','on');
    else
        set(handles.next_fine,'Enable','on');
        set(handles.next,'Enable','on');
        set(handles.prev_fine,'Enable','on');
        set(handles.prev,'Enable','on');
    end
    guidata(handles.figure1,handles);
end
% --- Create Preview Image, select upto 3 channels
function lstPreviewChan_Callback(hObject, eventdata, handles)
% describe inputs/outputs here
    RGBImage = double(zeros([size(handles.OrigImgChannel{1,1}),3])); %initialize matrix to accept RGB values
    ColorIndex=0;
    ChannelIndex = get(handles.lstPreviewChan, 'Value');
    if length(ChannelIndex) > 3
        errordlg('You can only select up to 3 channels for display');
    else
        % adapt to bit depth
        switch class(handles.OrigImgChannel{handles.CurImgNo,1})
        case 'uint8'
            scl=255;
        case 'uint16'
            scl=65535;
        otherwise
            warning('unsupported bit depth')
            scl=255;
        end

        for DispIndx = ChannelIndex %Assumes that max of 3 channels are selected
            ColorIndex = ColorIndex + 1;
            RGBImage(:,:,ColorIndex) = double((handles.OrigImgChannel{handles.CurImgNo,DispIndx})./scl); %normalize to 1
        end
        
        %Show Preview image
        axes(handles.lsmimg);
        handles = cla_lsmimg(handles);
        imshow(RGBImage);
        if (handles.l > 1)
            handles = PlotPreview(handles);
        end
    end
    if (isempty(handles.Data(handles.CurImgNo).Meas(1).Channel))
       handles = ShowMeasurement(handles, EmptyMeasStructure(length(handles.ImgChannel(handles.CurImgNo,:))), handles.showid, handles.l);
    else
       handles = ShowMeasurement(handles, handles.Data(handles.CurImgNo).Meas(handles.showid), handles.showid, handles.l);
    end
    guidata(handles.figure1,handles);
end
function lstPreviewChan_CreateFcn(hObject, eventdata, handles)
    % hObject    handle to lstPreviewChan (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    empty - handles not created until after all CreateFcns called

    % Hint: listbox controls usually have a white background on Windows.
    %       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end
end
% --- Image in the stack
function totalimages_CreateFcn(hObject, eventdata, handles)
% hObject    handle to totalimages (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
end
function totalimages_DeleteFcn(hObject, eventdata, handles)
% hObject    handle to totalimages (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
end
function totalimages_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to totalimages (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
end
% --- Support functions to clear preview and analsis window
function handles = cla_procimg(handles)
    cla;
    handles.Vectors =[]; %initialize the pointer
    handles.ICSResults =[];
    handles.VesselLineHandle =[];
    handles.ProfileLineHandle = [];
    handles.ROILineHandle = [];
end
function handles = cla_lsmimg(handles)
    cla;
    handles.VesselLinePreHandle =[];
    handles.ProfileLinePreHandle =[];
    handles.ROILinePreHandle =[];
end

%% 5.1 Select ROI and calculate measurements in ROI
%% 5.2 Select Profile
%% 5.3 Select Vessel Orientation
% --- SELECT ROI.
function analyze_Callback(hObject, eventdata, handles)
% hObject    handle to analyze (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    TempTypeOfIn = get(handles.TypeOfInterest_mnu,'String');
    handles.CurMeas.Type=TempTypeOfIn{get(handles.TypeOfInterest_mnu,'Value')};% 'Reference';
    handles.CurMeas.Channel = get(handles.popAnalysisChan,'Value');
    
    handles = ShowMeasurement(handles, handles.CurMeas, handles.l+1, handles.l+1);
    axes(handles.procimg);
    displayimage=GetDisplayImg(handles);
   
    [handles]=ROI(handles);
    
    handles = ShowMeasurement(handles, handles.CurMeas, handles.l+1, handles.l+1);
   
    set(handles.save,'Enable','on');
    
    %save variables  
    guidata(handles.figure1,handles);
end
% --- Support Function ROI analysis on all channels; calls getpoints to define ROI
function handles = ROI(handles)
% Will do ROI analysis on all channels 

    % Display the image and get image size
    fighandle = handles.figure1;
    imhandle=handles.DisplayImgHandle;
    
    NoOfChannels = length(handles.ImgChannel(handles.CurImgNo,:));

    % work in analysis window, get hold on axis
    axishandle = handles.procimg;
    im = handles.ImgChannel{handles.CurImgNo,get(handles.popAnalysisChan,'Value')};
    [nrows,ncols,ncolors] = size(im);
    axes(handles.procimg);
    hold on;
    
    % Calculate Vectors for ROI analysis if they have not yet been
    % calcualted
    if (isempty(handles.Vectors))
       handles = VectorUpdate(handles);
       % handles.VectorField =  FindVectors(handles,im);
       % handles.Vectors=quiver(handles.VectorField.x,handles.VectorField.y,handles.VectorField.u,handles.VectorField.v,'r-');
    end
    set(handles.VectorEnable,'Value',1);
    
    % ICS update so that respective field in measurement structure is not empty
    if (isempty(handles.ICSResults))
       handles = ICSUpdate(handles);
    end
    set(handles.ICSEnable,'Value',1);
    
    % Get the ROI interactively
    if ~isempty(handles.ROILineHandle)
        delete(handles.ROILineHandle);
        handles.ROILineHandle=[];
    end

    % Reuse previous ROI ?
    if ( get(handles.reuseROI, 'Value') && ~isempty(handles.previousROI_x) )
        x=handles.previousROI_x;
        y=handles.previousROI_y;
    else % no get new one
        [x , y] = getpoints(axishandle,handles);
        handles.previousROI_x=x;
        handles.previousROI_y=y;
    end
    
    % Calculate ROI area
    n = length(x);
    diffx = [diff(x) (x(1) - x(n)) ];
    diffy = [diff(y) (y(1) - y(n)) ];
    handles.CurMeas.PixArea = abs(sum(y .* diffx + diffx .* diffy ./2));
    handles.CurMeas.ROIx = x;
    handles.CurMeas.ROIy = y; 
    handles.datavalues.apix=handles.CurMeas.PixArea;
    
    % Change the pointer
    set(fighandle, 'Pointer', 'watch');

    %Calculate the ROI area in square point units
    % following code is not needed
    % pixarea = (diff(XData) +1) * (diff(YData) + 1); % is total area of
    % image, not ROI

    % Create the smallest rectangular grid around the ROI
    % Size of Image Area
    XData = get(imhandle, 'XData'); 
    YData = get(imhandle, 'YData');
    % corners of the rectangle around the ROI
    xmingrid = max( XData(1), floor(min(x))  );
    xmaxgrid = min( XData(2),  ceil(max(x))  );
    ymingrid = max( YData(1), floor(min(y))  );
    ymaxgrid = min( YData(2),  ceil(max(y))  );  
    xgrid = xmingrid:xmaxgrid; % all x coordinates of points rectangle
    ygrid = ymingrid:ymaxgrid; % all y coordinates of points in rectangle
    
    % Analyze only the points inside the polygon
    [X, Y] = meshgrid(xgrid, ygrid);
	k_inside= inpolygon(X,Y, x,y);
    Xin = X(k_inside); 
    Yin = Y(k_inside);
    clear X Y
	% Determine the center of the polygon
	handles.CurMeas.ROIcenter =  [mean(Xin(:)),mean(Yin(:))];
    clear Xin Yin
	
    % create a logical mask for the rectangle of interest
    mask = false(nrows,ncols); % mask of whole image
    mask(ygrid,xgrid) = 1; % mask of rectangle containing ROI
    mask(logical(mask)) = logical(k_inside); % sets rectange in whole image to ROI mask
    clear k_inside
	

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Intensity calculations
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Calculate the mean, SD, etc... and as fields add to roi structure
    % do this for each channel
    for i=1:NoOfChannels
      % determine bitdepth, so we can adjust histrogram size
      switch class(handles.ImgChannel{handles.CurImgNo,i})
        case 'uint8'
            scl=255;
        case 'uint16'
            scl=65535;
        otherwise
            warning('unsupported bit depth')
            scl=255;
      end
      % do the calculations
      roicidata = double(handles.ImgChannel{handles.CurImgNo,i});
      handles.CurMeas.Intensity(i).mean =   mean(roicidata(mask));
      handles.CurMeas.Intensity(i).std  =    std(roicidata(mask));
      handles.CurMeas.Intensity(i).min  =    min(roicidata(mask));
      handles.CurMeas.Intensity(i).max  =    max(roicidata(mask)); 
      handles.CurMeas.Intensity(i).median= median(roicidata(mask));
      [handles.CurMeas.Intensity(i).hist.n,handles.CurMeas.Intensity(i).hist.x] = hist(roicidata(mask),scl);
    end;
    
    handles.ROILineHandle=plot(handles.CurMeas.ROIx,handles.CurMeas.ROIy,'g-'); 
  
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Vector Field
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % calculate Vector field data inside ROI

    handles.CurMeas.Orientation.qver = [handles.VectorField.x,handles.VectorField.y,handles.VectorField.u,handles.VectorField.v];

    orientation = double(handles.VectorField.Orientation(mask));
    relia = double(handles.VectorField.Reliability(mask));
    ind=find(relia<str2double(get(handles.reliability, 'String')));
    orientation(ind)=[];
    
    handles.CurMeas.Orientation.Angles= (180/pi)*(orientation);
    handles.CurMeas.Orientation.mean= (180/pi)*mean(orientation);
    handles.CurMeas.Orientation.std = (180/pi)*std(orientation);
    
    % Add the date and time for future reference
	handles.CurMeas.Timestamp = datestr(now);
    % Add the mask
	handles.CurMeas.Mask = mask;

    % Reset pointer shape5
    set(fighandle, 'Pointer', 'arrow');
    
    % handlesOUT=handles;
end % ROI
% --- Support Function Collect ROI polygon mouse position on Analysis Window (used in ROI)
function [xs,ys] = getpoints(axishandle,handles)

    % Find parent figure for the argument axishandle
    axes(axishandle);
    %figure(get(axishandle, 'Parent'));
	
    % Change pointer shape
	ptrc =  ones(16)+1; ptrc( 1, :) = 1;  ptrc(16, :) = 1; ptrc(: , 1) = 1; 
    ptrc(: ,16) = 1;    ptrc(1:4,8:9) = 1; ptrc(8:9,1:4) = 1;
    ptrc(13:16, 8:9 ) = 1;  ptrc( 8:9 ,13:16) = 1;  ptrc(5:12,5:12) = NaN;
    set(gcf,'Pointer', 		'custom',...
 	'PointerShapeCData', 	ptrc,...
 	'PointerShapeHotSpot',	[8 8]);

	% Prepare for interactive collection of ROI boundary points
	hold on
    handles.pointhandles = [];
    xpts = [];
    ypts = [];
    handles.splinehandle= [];
    n = 0;
    but = 1;
    BUTN = 0;
    KEYB = 1;
    done =0;
	guidata(handles.figure1,handles);	
    
    % Loop until right hand mouse button or keayboard is pressed
	while ~done;  
        % Analyze each buttonpressed event
        keyb_or_butn = waitforbuttonpress;
        if keyb_or_butn == BUTN;
            currpt = get(axishandle, 'CurrentPoint');
            seltype = get(gcf,'SelectionType');
            switch seltype 
            case 'normal',
                but = 1;
            case 'alt',
                but = 2;
            otherwise,
                but = 2;
            end;          
        elseif keyb_or_butn == KEYB
            but = 2;
        end; 
  	
        %Get coordinates of the last buttonpressed event
        xi = currpt(2,1);
        yi = currpt(2,2);
  	
        [TempRows,TempCols] = size(handles.ImgChannel{handles.CurImgNo,1});
        % Start a spline throught the points or 
        % update the line through the points with a new spline
  	
        if (but==1) && (xi<=TempRows) && (xi>=0) && (yi<=TempCols) && (yi>=0)
            if ~isempty(handles.splinehandle)
                delete(handles.splinehandle);
            end;
            handles.pointhandles(n+1) = plot(xi,yi,'ro');
            n = n+1;
            xpts(n,1) = xi;
            ypts(n,1) = yi;
        
            % Draw a spline line through the points
            if n > 1
                t = 1:n;
                ts = 1: 1 : n;
                xs = spline(t, xpts, ts);
                ys = spline(t, ypts, ts);
                handles.splinehandle = plot(xs,ys,'r-');
            end;
        elseif but > 1
            % Exit for right hand mouse button or keyboard input
            done = 1;
        end;
    end;
	
    % Add first point to the end of the vector for spline 
	xpts(n+1,1) = xpts(1,1);
    ypts(n+1,1) = ypts(1,1);
          
    % (re)draw the final spline 
	if ~ isempty(handles.splinehandle)
        delete(handles.splinehandle);
    end;    

    t = 1:n+1;
    ts = 1: 1 : n+1;
    xs = spline(t, xpts, ts);
    ys = spline(t, ypts, ts);

    %linehandle = plot(xs,ys,'r-');
    %drawnow;
    
    % Delete the point markers 
    if ~isempty(handles.pointhandles)
        delete(handles.pointhandles);
    end;
	
    % Reset pointershape 
    set(gcf,'Pointer','arrow');

    %guidata(handles.figure1,handles);
end
% --- PROFILE
function Line_Callback(hObject, eventdata, handles)
    % hObject    handle to Line (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    structure with handles and user data (see GUIDATA)
    handles.CurMeas.Channel = get(handles.popAnalysisChan,'Value');
    handles = ShowMeasurement(handles, handles.CurMeas, handles.l+1, handles.l+1);
    
    % Reuse Previous Line Handle ?
    if ( get(handles.reuseline, 'Value') && ~isempty(handles.previous_xpts_Profile) )
        xpts=handles.previous_xpts_Profile;
        ypts=handles.previous_ypts_Profile;
        axes(handles.procimg);
    	hold on
        linehandle=plot(xpts,ypts,'y-');
    else % no get new one
        [xpts ypts linehandle]=DrawLine(handles.procimg,handles);
        handles.previous_xpts_Profile=xpts;
        handles.previous_ypts_Profile=ypts;
    end
        
    if (~isempty(handles.ProfileLineHandle))
        delete (handles.ProfileLineHandle)
    end
    handles.ProfileLineHandle = linehandle;

    slope=(ypts(2)-ypts(1))/(xpts(2)-xpts(1));
    LineLength = sqrt((xpts(2)-xpts(1))^2+(ypts(2)-ypts(1))^2);
    % Create Center Line, One Unit Intervals
    xs=xpts(1):(xpts(2)-xpts(1))/LineLength:xpts(2);
    ys=ypts(1):(ypts(2)-ypts(1))/LineLength:ypts(2);

    if isempty(xs)
        xs=ones(1,length(ys)).*xpts(1);
    elseif isempty(ys)
        ys=ones(1,length(xs)).*ypts(1);
    end

    width=str2double(get(handles.linewidth, 'String'));
    widthline=[-width:width];

    % Faulty Code
    %    Phi = pi/2-atan(slope);
    %    if (abs(slope) <1)
    %        Y = widthline;
    %        X = Y./tan(Phi);
    %        X(X<0)=ceil(X(X<0));
    %        X(X>=0)=floor(X(X>=0));
    %    else
    %        X = widthline;
    %        Y = tan(Phi).*widthline;
    %        Y(Y<0)=ceil(Y(Y<0));
    %        Y(Y>=0)=floor(Y(Y>=0));
    %    end

    Phi = pi/2-atan(slope);
    Y=-sin(Phi)*widthline;
    X=cos(Phi)*widthline;
    Y(Y<0)=floor(Y(Y<0));
    Y(Y>=0)=ceil(Y(Y>=0));
    X(X<0)=floor(X(X<0));
    X(X>=0)=ceil(X(X>=0));

    NoOfChannels = length(handles.ImgChannel(handles.CurImgNo,:));

    for CurChan = 1:NoOfChannels
        for q=1:1:length(xs)    
            temp= double(handles.ImgChannel{handles.CurImgNo,CurChan}([floor(ys(q))+Y],[floor(xs(q))+X]));  
            linecon(q)=mean(temp(:));
            % plot([floor(xs(q))+X],[floor(ys(q))+Y],'o')
        end
        handles.CurMeas.Profile.Value{CurChan}=linecon;
    end
    handles.CurMeas.Profile.X=xs;
    handles.CurMeas.Profile.Y=ys;
    
    CurAnalChan = get(handles.popAnalysisChan,'Value');
    
    axes(handles.axeProfile)
    cla;
    plot(handles.CurMeas.Profile.Value{CurAnalChan});
    xlim([0,length(handles.CurMeas.Profile.Value{CurAnalChan})]);
    set(handles.pnlProfile,'Title',['Profile for Channel ',num2str(CurAnalChan)]);
    set(handles.save,'Enable','on');
    guidata(handles.figure1,handles);
end
% --- Adjust Linewidth for Profile
function linewidth_Callback(hObject, eventdata, handles)
% hObject    handle to linewidth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of linewidth as text
%        str2double(get(hObject,'String')) returns contents of linewidth as a double
end
% --- Linewidth.
function linewidth_CreateFcn(hObject, eventdata, handles)
% hObject    handle to linewidth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end
% --- Support Function Collect Line location on Analysis Window
function [xpts,ypts, linehandle] = DrawLine(axishandle,handles)

    % Find parent figure for the argument axishandle
    axes(axishandle);
	
    % Change pointer shape
	ptrc =  ones(16)+1;
    ptrc( 1, :) = 1; 
    ptrc(16, :) = 1; 
    ptrc(: , 1) = 1; 
    ptrc(: ,16) = 1; 
    ptrc(1:4,8:9) = 1;
    ptrc(8:9,1:4) = 1;
    ptrc(13:16, 8:9 ) = 1;
    ptrc( 8:9 ,13:16) = 1;
    ptrc(5:12,5:12) = NaN;
    set(gcf,'Pointer', 		'custom',...
 	'PointerShapeCData', 	ptrc,...
 	'PointerShapeHotSpot',	[8 8]);

	% Prepare for interactive collection of ROI boundary points
	hold on
    handles.pointhandles = [];
    xpts = [];
    ypts = [];
    handles.splinehandle= [];
    n = 0;
    but = 1;
    BUTN = 0;
    KEYB = 1;
    done = 0;
	
    guidata(handles.figure1,handles);	
    
    % Take the two points on the vessel
	while(n<2)  
  	     % Analyze each buttonpressed event
         keyb_or_butn = waitforbuttonpress;
         if keyb_or_butn == BUTN;
           currpt = get(axishandle, 'CurrentPoint');
         end 

         %Get coordinates of the last buttonpressed event
         xi = currpt(2,1);
         yi = currpt(2,2);

         [TempRows,TempCols] = size(handles.ImgChannel{handles.CurImgNo,1});
         % Start a spline throught the points or 
         % update the line through the points with a new spline
         if (but==1) && (xi<=TempRows) && (xi>=0) && (yi<=TempCols) && (yi>=0)  	
              handles.pointhandles(n+1) = plot(xi,yi,'yo');
              n = n+1;
              xpts(n,1) = floor(xi);
              ypts(n,1) = floor(yi);

              % Draw a spline line through the points
              if n > 1
                    linehandle = plot(xpts,ypts,'y-');
              end
         end
    end
    
    % drawnow;
 
    % Delete the point markers 
    if ~isempty(handles.pointhandles)
        delete(handles.pointhandles);
    end
	
    % Reset pointershape 
    set(gcf,'Pointer','arrow');
end
% --- Indicate Vessel Orientation.
function vessel_Callback(hObject, eventdata, handles)
    % hObject    handle to vessel (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    structure with handles and user data (see GUIDATA)
    handles.CurMeas.Channel = get(handles.popAnalysisChan,'Value');
    handles = ShowMeasurement(handles, handles.CurMeas, handles.l+1, handles.l+1);

    % Reuse previous Line ?
    % Reuse Previous Line Handle ?
    if (get(handles.reusevessel, 'Value') &&  ~isempty(handles.previous_xpts_Vessel))
        xpts=handles.previous_xpts_Vessel;
        ypts=handles.previous_ypts_Vessel;
        axes(handles.procimg);
    	hold on
        linehandle=plot(xpts,ypts,'y-');
    else % no get new one
        [xpts ypts linehandle]=DrawLine(handles.procimg,handles);
        handles.previous_xpts_Vessel=xpts;
        handles.previous_ypts_Vessel=ypts;
    end
        
    if (~isempty(handles.VesselLineHandle))
        delete (handles.VesselLineHandle)
    end
    handles.VesselLineHandle = linehandle;
    set(handles.VesselLineHandle,'Color','c');

    vesselangle=180/pi*atan((ypts(2)-ypts(1))/(xpts(2)-xpts(1)));

    handles.CurMeas.Vessel.Angle=vesselangle;
    handles.CurMeas.Vessel.X = xpts;
    handles.CurMeas.Vessel.Y = ypts;
    handles = ShowMeasurement(handles, handles.CurMeas, handles.l+1, handles.l+1);
    guidata(handles.figure1,handles);	
    
    set(handles.save,'Enable','on');
end
% --- ReuseROI, Profile, Vessel Orientation
function reuse_ROI_Callback(hObject, eventdata, handles)
% hObject    handle to reuseROI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of reuseROI
end
function reuse_profile_Callback(hObject, eventdata, handles)
% hObject    handle to reuseline (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of reuseline
end
function reuse_vessel_orient_Callback(hObject, eventdata, handles)
% hObject    handle to reusevessel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of reusevessel
end

%% 6 Measurements; Save, Delete and Browse
% --- Select MeasChannel to display or save.
function popMeasChan_Callback(hObject, eventdata, handles)
    if (isempty(handles.Data(handles.CurImgNo).Meas(1).Channel))
        handles = ShowMeasurement(handles, EmptyMeasStructure(length(handles.ImgChannel(handles.CurImgNo,:))), handles.showid, handles.l);
    else
        handles = ShowMeasurement(handles, handles.Data(handles.CurImgNo).Meas(handles.showid), handles.showid, handles.l);
    end
    guidata(handles.figure1,handles);
%      figure;
%      bar(handles.Data(handles.CurImgNo).Meas(handles.showid).Intensity(get(hObject,'Value')).hist.x,...
%          handles.Data(handles.CurImgNo).Meas(handles.showid).Intensity(get(hObject,'Value')).hist.n)
end
function popMeasChan_CreateFcn(hObject, eventdata, handles)
    % hObject    handle to popMeasChan (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    empty - handles not created until after all CreateFcns called

    % Hint: popupmenu controls usually have a white background on Windows.
    %       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end
end
% --- Next Measurement
function next2_Callback(hObject, eventdata, handles)
    % hObject    handle to next2 (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    structure with handles and user data (see GUIDATA)
       handles.showid=handles.showid +1;
%       showdata(handles);
       handles = ShowMeasurement(handles, handles.Data(handles.CurImgNo).Meas(handles.showid), handles.showid, handles.l);
       %handles = PlotPreview(handles);
       guidata(handles.figure1,handles);
end
function next2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to next2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

    set(hObject,'Enable','off');
end
% --- Previous Measurement
function prev2_Callback(hObject, eventdata, handles)
    % hObject    handle to prev2 (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    structure with handles and user data (see GUIDATA)
       handles.showid=handles.showid -1;
%       showdata(handles);
       handles = ShowMeasurement(handles, handles.Data(handles.CurImgNo).Meas(handles.showid), handles.showid, handles.l);
       %handles = PlotPreview(handles);
       guidata(handles.figure1,handles);
end
function prev2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to prev2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

    set(hObject,'Enable','off');
end
% --- Save Measurement
function save_Callback(hObject, eventdata, handles)
    % hObject    handle to save (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    structure with handles and user data (see GUIDATA)

    [r c]=size(handles.filename);
    filename=handles.filename(1:(c-4));
    
    % Save
    handles.Data(handles.CurImgNo).Meas(handles.l+1) = handles.CurMeas;
    Data=handles.Data;
    save(filename,'Data');

    % Update display
    set(hObject,'Enable','off');
    set(handles.delete,'Enable','on');
 
    handles.l=handles.l+1;
    handles.showid=handles.l;
    handles.CurMeas = EmptyMeasStructure(length(handles.ImgChannel(handles.CurImgNo,:)));
    handles = ShowMeasurement(handles, handles.Data(handles.CurImgNo).Meas(handles.showid), handles.showid, handles.l);
    if(~isempty(handles.ROILineHandle))
        delete(handles.ROILineHandle);
        handles.ROILineHandle =[];
    end
    if(~isempty(handles.ProfileLineHandle))
        delete(handles.ProfileLineHandle);
        handles.ProfileLineHandle =[];
    end
    if(~isempty(handles.VesselLineHandle))
        delete(handles.VesselLineHandle);
        handles.VesselLineHandle =[];
    end
    guidata(handles.figure1,handles);

    %showdata(handles);
end
function save_CreateFcn(hObject, eventdata, handles)
% hObject    handle to save (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
set(hObject,'Enable','off');
end
% --- Delete Masurement
function delete_Callback(hObject, eventdata, handles)
    % hObject    handle to delete (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    structure with handles and user data (see GUIDATA)
    [r c]=size(handles.filename);
    filename=handles.filename(1:(c-4));

    TempData=handles.Data(handles.CurImgNo);
    handles.Data(handles.CurImgNo)=[];

    handles.Data(handles.CurImgNo).Meas=TempData.Meas(1:handles.showid-1);
    for TempK = handles.showid:length(TempData.Meas)-1
        handles.Data(handles.CurImgNo).Meas(TempK) = TempData.Meas(TempK+1);
    end
    handles.l = handles.l-1;

    if(handles.l==0)
        set(handles.delete,'Enable','off');
    end
    handles.showid=handles.l;

    Data=handles.Data;
    save(filename,'Data');
    if(handles.showid==0)
       handles = ShowMeasurement(handles, EmptyMeasStructure(length(handles.ImgChannel(handles.CurImgNo,:))), handles.showid, handles.l);
    else
       handles = ShowMeasurement(handles, handles.Data(handles.CurImgNo).Meas(handles.showid), handles.showid, handles.l);
    end
    guidata(handles.figure1,handles);
end
function delete_CreateFcn(hObject, eventdata, handles)
    % hObject    handle to delete (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    empty - handles not created until after all CreateFcns called
     set(hObject,'Enable','off');
end
% --- Create Profile
function btnProfile_Callback(hObject, eventdata, handles)
    CurImgNo = handles.CurImgNo;
    CurMeasNo = handles.showid;
    CurChanNo = get(handles.popMeasChan,'Value');
    
    axes(handles.axeProfile)
    cla;
    % added if structure UU
    if ((CurImgNo>0) && (CurMeasNo>0) && (CurChanNo>0))
        plot(handles.Data(CurImgNo).Meas(CurMeasNo).Profile.Value{CurChanNo});
        xlim([0,length(handles.Data(CurImgNo).Meas(CurMeasNo).Profile.Value{CurChanNo})]);
        set(handles.pnlProfile,'Title',['Profile for channel ',num2str(CurChanNo)]);
    end
end
% --- Select Measurement saveing type .
function TypeOfInterest_mnu_Callback(hObject, eventdata, handles)
    % hObject    handle to TypeOfInterest_mnu (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    structure with handles and user data (see GUIDATA)
    TempTypeOfIn = get(handles.TypeOfInterest_mnu,'String');
    handles.CurMeas.Type=TempTypeOfIn{get(handles.TypeOfInterest_mnu,'Value')};
    handles = ShowMeasurement(handles, handles.CurMeas, handles.l+1, handles.l+1);   
    guidata(handles.figure1,handles);
end
function TypeOfInterest_mnu_CreateFcn(hObject, eventdata, handles)
    % hObject    handle to TypeOfInterest_mnu (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    empty - handles not created until after all CreateFcns called

    % Hint: popupmenu controls usually have a white background on Windows.
    %       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end
end
% --- Display ROIHist.
function btnROIHist_Callback(hObject, eventdata, handles)
    CurImgNo = handles.CurImgNo;
    CurMeasNo = handles.showid;
    CurChanNo = get(handles.popMeasChan,'Value');
    
    % added if structure UU
    if ( (CurImgNo>0) && (CurMeasNo>0) && (CurChanNo>0) )
    % Histogram of intensity
        figure;
        bar(handles.Data(CurImgNo).Meas(CurMeasNo).Intensity(CurChanNo).hist.x,...
            handles.Data(CurImgNo).Meas(CurMeasNo).Intensity(CurChanNo).hist.n)
        title(['Histogram of intensity values in ROI for Channel ',num2str(CurChanNo)]);
        xlabel('Intensity Values');
        ylabel('Frequency');
    % Histogram of Vector Field
        if ~isempty(handles.Data(CurImgNo).Meas(CurMeasNo).Orientation.Angles)
            figure;
            hist(handles.Data(CurImgNo).Meas(CurMeasNo).Orientation.Angles,[0:5:180]);
            hold on;
            if ~isempty(handles.Data(CurImgNo).Meas(CurMeasNo).Vessel.Angle)
                plot(handles.Data(CurImgNo).Meas(CurMeasNo).Vessel.Angle,0,'or');
            end
            title(['Histogram of angles in ROI for Channel ',num2str(CurChanNo)]);
            xlabel('Angle Values');
            ylabel('Frequency');
        end
    end
end
% --- Support function: plot ROIpolygon, profileline, vesselline on preview
function handles = PlotPreview(handles)
    if(~isempty(handles.ROILinePreHandle))
        delete(handles.ROILinePreHandle);
        handles.ROILinePreHandle =[];
    end
    if(~isempty(handles.ProfileLinePreHandle))
        delete(handles.ProfileLinePreHandle);
        handles.ProfileLinePreHandle =[];
    end
    if(~isempty(handles.VesselLinePreHandle))
        delete(handles.VesselLinePreHandle);
        handles.VesselLinePreHandle =[];
    end
    axes(handles.lsmimg);
    hold on;

    if (handles.showid ~= 0)
        handles.ROILinePreHandle = plot(handles.Data(handles.CurImgNo).Meas(handles.showid).ROIx,...
                                        handles.Data(handles.CurImgNo).Meas(handles.showid).ROIy,...
                                        '-g');
        handles.ProfileLinePreHandle = plot(handles.Data(handles.CurImgNo).Meas(handles.showid).Profile.X,...
                                            handles.Data(handles.CurImgNo).Meas(handles.showid).Profile.Y,...
                                            '-y');
        handles.VesselLinePreHandle = plot(handles.Data(handles.CurImgNo).Meas(handles.showid).Vessel.X,...
                                           handles.Data(handles.CurImgNo).Meas(handles.showid).Vessel.Y,...
                                           '-c'); 
    end
end
% --- Support function: Returns an empty structure with all the fields needed for measurement done on an image
function Meas = EmptyMeasStructure(NoOfChan)
    for i=1:NoOfChan
        Meas.Intensity(i).mean=[];
        Meas.Intensity(i).std=[];
        Meas.Intensity(i).median=[];
        Meas.Intensity(i).max=[];
        Meas.Intensity(i).min=[];
        Meas.Intensity(i).hist.n=[];
        Meas.Intensity(i).hist.x=[];        
        Meas.Profile.Value{i}=[];
    end
        Meas.Profile.X=[];
        Meas.Profile.Y=[];
%       Meas.Profile.Value=[];
        Meas.Orientation.Angles=[];
        Meas.Orientation.qver=[];
        Meas.Orientation.mean=[];
        Meas.Orientation.std=[];
        Meas.Channel=[];
        Meas.Type=[];
        Meas.Mask=[];
        Meas.ROIx=[];
        Meas.ROIy=[];
%       Meas.SeqNo=[];
        Meas.Timestamp=[];
        Meas.PixArea=[];
        Meas.ROIcenter=[];
        Meas.Vessel.Angle=[];
        Meas.Vessel.X=[];
        Meas.Vessel.Y=[];
        Meas.ICS=[];
end
% --- Support function; Show measurements
function handles = ShowMeasurement(handles, Meas, MeasNo, TotalMeas)
        
        if (MeasNo>=TotalMeas)
            set(handles.next2,'Enable','off');
        else
            set(handles.next2,'Enable','on');
        end
        if (MeasNo<=1)
            set(handles.prev2,'Enable','off');
        else
            set(handles.prev2,'Enable','on');
        end
        if (TotalMeas>handles.l)
            set(handles.delete,'Enable','off');
            set(handles.popMeasChan,'Enable','off');
            MeasChan = get(handles.popAnalysisChan,'Value');
            set(handles.popMeasChan,'Value',MeasChan);
        else
            set(handles.delete,'Enable','on');
            handles = PlotPreview(handles); % This also indicates ROI, profile, vessel location
            set(handles.popMeasChan,'Enable','on');
            MeasChan = get(handles.popMeasChan,'Value');
        end
        if (isempty(Meas.ROIx))
            set(handles.btnROIHist,'Enable','off');
        else
            set(handles.btnROIHist,'Enable','on');
        end
        if (isempty(Meas.Profile.X))
            set(handles.btnProfile,'Enable','off');
        else
            set(handles.btnProfile,'Enable','on');
        end
        
        % Populate the Measurement Text Display
        set(handles.type, 'String', ['Type: ', Meas.Type]);
        set(handles.channel, 'String', ['Channel: ', num2str(Meas.Channel)]);
        set(handles.vesselorient,'String',['Vessel Orient: ',num2str(Meas.Vessel.Angle)]);
        set(handles.pointnumber, 'String', ['Meas. Number: ', num2str(MeasNo),'/', num2str(TotalMeas)]);
        set(handles.timedate, 'String', ['Time/Date: ', Meas.Timestamp]);
        set(handles.roicenter, 'String', ['Roi Center [x,y]: ', num2str(round(Meas.ROIcenter))]);
        set(handles.pixelsarea, 'String', ['Pixels Area: ', num2str(round(Meas.PixArea))]);
        set(handles.mean, 'String', ['Mean: ', num2str(Meas.Intensity(MeasChan).mean)]);
        set(handles.stdev, 'String', ['St. Dev.: ', num2str(Meas.Intensity(MeasChan).std)]);
        set(handles.min, 'String', ['Min: ', num2str(Meas.Intensity(MeasChan).min)]);
        set(handles.max, 'String', ['Max: ', num2str(Meas.Intensity(MeasChan).max)]);
        set(handles.median, 'String', ['Median: ', num2str(Meas.Intensity(MeasChan).median)]);
        set(handles.orientation, 'String', ['Orientation: ', num2str(Meas.Orientation.mean)]);    
        
        % Populate Analysis Text Display
        try
            if (~isempty(Meas.ICS))
                ICSFit=Meas.ICS;                     
                ICSResults = sprintf(['Ampl.: ', num2str(ICSFit(1),3), ' Offs.: ', ...
                num2str(ICSFit(5),3), '\nMSTD: ', num2str(ICSFit(3),3), ...
                ' mSTD: ', num2str(ICSFit(4),3), '\nOrient.: ' num2str(ICSFit(2),3) ]);
                set(handles.AnalysisResultsTxt, 'String', ICSResults);
            end
        catch ME
            % old version of measurement structure, does not have ICS
            Warning('Did not find ICS data in measurement structure')
        end
end

%% 7 Analysis
% --- Select Channel and Conducts Analysis (e.g. vector)
function popAnalysisChan_Callback(hObject, eventdata, handles)
    handles.CurMeas = EmptyMeasStructure(length(handles.ImgChannel(handles.CurImgNo,:)));
    handles.CurMeas.Channel = get(handles.popAnalysisChan,'Value');
    handles = ShowMeasurement(handles, handles.CurMeas, handles.l+1,handles.l+1);
    if (~isempty(handles.ROILineHandle))
        delete(handles.ROILineHandle);
        handles.ROILineHandle = [];
    end
    if (~isempty(handles.ProfileLineHandle))
        delete(handles.ProfileLineHandle);
        handles.ProfileLineHandle = [];
    end
    if (~isempty(handles.VesselLineHandle))
        delete(handles.VesselLineHandle);
        handles.VesselLineHandle = [];
    end
    axes(handles.axeProfile);
    cla;
    plot(0,0);
    handles = VectorUpdate(handles);
    % Other Analsys done here
    %
    %
    guidata(handles.figure1,handles);
end
function popAnalysisChan_CreateFcn(hObject, eventdata, handles)
    % hObject    handle to popAnalysisChan (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    empty - handles not created until after all CreateFcns called

    % Hint: popupmenu controls usually have a white background on Windows.
    %       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end
end
% --- Manually Redo Analysis.
% If contrast is changed and invert and normalize, analysis is not
% automatically recalculated. User should decide to update manually.
function RedoAnalysis_Callback(hObject, eventdata, handles)
% hObject    handle to RedoAnalysis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Vector Update
    valueon=get(handles.VectorEnable,'Value');
    if (valueon==1)
            handles = VectorUpdate(handles);
    end
    
%ICS Update
    valueon=get(handles.ICSEnable,'Value');
    if (valueon==1)
            handles = ICSUpdate(handles);
    end
    guidata(handles.figure1,handles);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Orientation calculation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Calculate & update the vector display
% --- Deal with Vector Enable
function VectorEnable_Callback(hObject, eventdata, handles)
% hObject    handle to VectorEnable (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of VectorEnablefunction VectorEnable(hObject, eventdata, handles)
    % Vector
    valueon=get(handles.VectorEnable,'Value');
    if (valueon==1)
        if(~isempty(handles.Vectors))
            set(handles.Vectors,'Visible','on');
        else
            %handles = VectorUpdate(hObject, eventdata,handles);
            handles = VectorUpdate(handles);
        end
    else
        if(~isempty(handles.Vectors))
            set(handles.Vectors,'Visible','off');
        end
    end
    guidata(handles.figure1,handles);
end
% Support Function: Vector Update
function handles = VectorUpdate(handles)
% function handles = VectorUpdate(hObject, eventdata, handles)
   % This seems to be redundant because display image is not used later
   % Alternative would be to use refreshdisplay function
   % displayimage=GetDisplayImg(handles); % Calclates image with color
   % mixer and scale bar
   if (~isempty(handles.Vectors))
        delete(handles.Vectors);
        handles.Vectors=[];
   end
   analysisimage = handles.ImgChannel{handles.CurImgNo,get(handles.popAnalysisChan,'Value')};
   if (get(handles.InvertImg, 'Value') == 1)
       % Invert Image First
       analysisimage = invertimg(analysisimage);
   end
   if (get(handles.NormalizeImg, 'Value') == 1) 
       % Normalize Image First
       analysisimage = normalise(analysisimage);
   end
   VectorField =  FindVectors(handles,analysisimage);
   axes(handles.procimg);
   hold on;
   handles.Vectors=quiver(VectorField.x,VectorField.y,VectorField.u,VectorField.v,'r-');
   handles.VectorField = VectorField;
   set(handles.VectorEnable,'Value',1);
end
% --- Support Function: Calculates the vector field from the given image
function VectorField=FindVectors(handles,AnalysisImg)
        
        % 1
        % Identify ridge-like regions and normalise image
        blksze = str2double(get(handles.blocksize, 'String'));
        thresh = str2double(get(handles.threshold, 'String'));
        [normim, mask] = ridgesegment(AnalysisImg, blksze, thresh);

        % 2
        % Determine ridge orientations
        gradientsigma=str2double(get(handles.s1, 'String'));
        blocksigma=str2double(get(handles.s2, 'String'));
        orientsmoothsigma=str2double(get(handles.s3, 'String'));
        [orientim, reliability] = ridgeorient(normim, gradientsigma, blocksigma, orientsmoothsigma);

        % 3
        % Prepare results
        
        spacing = 10;%must be integer

        [rows, cols] = size(orientim);

        % lw = 2;             % linewidth
        len = 0.8*spacing;  % length of orientation lines

        % Subsample the orientation data according to the specified spacing

        s_orient = orientim(spacing:spacing:rows-spacing, ...
                  spacing:spacing:cols-spacing);

        s_reliability = reliability(spacing:spacing:rows-spacing, ...
                  spacing:spacing:cols-spacing);    

        xoff = len/2*cos(s_orient);
        yoff = len/2*sin(s_orient);    


        % Determine placement of orientation vectors
        [VectorField.x,VectorField.y] = meshgrid(spacing:spacing:cols-spacing, ...
                 spacing:spacing:rows-spacing);

        VectorField.x = VectorField.x-xoff;
        VectorField.y = VectorField.y-yoff;


        %remove vectors with reliability less than <input
        nofibers=find(s_reliability<str2double(get(handles.reliability, 'String')));

        orientationdisp=s_orient;
        orientationdisp(nofibers)=pi/2;
        xoff = len/2*cos(orientationdisp);
        orientationdisp=s_orient;
        orientationdisp(nofibers)=0;
        yoff = len/2*sin(orientationdisp);

        % Orientation vectors
        VectorField.u = xoff*2;
        VectorField.v = yoff*2;
        VectorField.Orientation = orientim;
        VectorField.Reliability = reliability;
end
% --- Vector Setting block
function blocksize_Callback(hObject, eventdata, handles)
    handles = VectorUpdate(handles);
    guidata(handles.figure1,handles);
end
% --- Vector Setting Threshold
function threshold_Callback(hObject, eventdata, handles)
    handles = VectorUpdate(handles);
    guidata(handles.figure1,handles);
end
% --- Vector Setting Reliability
function reliability_Callback(hObject, eventdata, handles)
    handles = VectorUpdate(handles);
    guidata(handles.figure1,handles);
end
function s1_Callback(hObject, eventdata, handles)
    handles = VectorUpdate(handles);
    guidata(handles.figure1,handles);
end
% --- Vector Setting s2
function s2_Callback(hObject, eventdata, handles)
    handles = VectorUpdate(handles);
    guidata(handles.figure1,handles);
end
% --- Vector Setting s3
function s3_Callback(hObject, eventdata, handles)
    handles = VectorUpdate(handles);
    guidata(handles.figure1,handles);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Correlation Calcuations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Caluclate the Image Correlation Function
% --- Deal with ICSEnable.
function ICSEnable_Callback(hObject, eventdata, handles)
% hObject    handle to ICSEnable (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of ICSEnable
    % ICS
    valueon=get(handles.ICSEnable,'Value');
    if (valueon==1)
        % if(~check_ICS_results)
        if(~isempty(handles.ICSResults))
            % update ics results in display only
            set(handles.AnalysisResultsTxt, 'Enable', 'on')
        else
            handles = ICSUpdate(handles);
        end
    else
        if(~isempty(handles.ICSResults))
            % set ICS display text to shaded/invisible
            set(handles.AnalysisResultsTxt, 'Enable', 'off')
        end
    end
    guidata(handles.figure1,handles);
end
% --- Vector Setting crop
function crop_Callback(hObject, eventdata, handles)
    handles = ICSUpdate(handles);
    guidata(handles.figure1,handles);
end
% --- Support Function: Calculates ICS of the given image
function handles = ICSUpdate(handles)
%function handles = ICSUpdate(hObject, eventdata, handles)
   % Clear results text
   if (~isempty(handles.ICSResults))
        handles.ICSResults=[];
   end
   % Prefrom preparation before ICS calculation
   analysisimage = handles.ImgChannel{handles.CurImgNo,get(handles.popAnalysisChan,'Value')};
    if (get(handles.InvertImg, 'Value') == 1)
        % Invert Image First
        analysisimage = invertimg(analysisimage);
    end
    if (get(handles.NormalizeImg, 'Value') == 1) 
       % Normalize Image First
        analysisimage = normalise(analysisimage);
    end
   % do the calculation
   CropSize = str2double(get(handles.crop, 'String'));
   CorrFac = str2double(get(handles.edt200um,'String'));
   PixSpace = str2double(get(handles.edtPixSpace,'String'));
   PixelSize = PixSpace*CorrFac;
   [ICSFit, ICS, ICScropped] = ICS2Di(analysisimage, PixelSize, CropSize);
   % Fit Paramter 'ICSFit' 
   % ICSFit(1) is the amplitude, 
   % ICSFit(2) is the orientation, 
   % ICSFit(3)& ICSFit(4) are the standard deviation major and minor,
   % ICSFit(5) is the offset 
   % Not Used: ICSFit(6),ICSFit(7) is the center offset i.e. (x0,y0).
   ICSResults = sprintf(['Ampl.: ', num2str(ICSFit(1),3), ' Offs.: ', ...
       num2str(ICSFit(5),3), '\nMSTD: ', num2str(ICSFit(3),3), ...
       ' mSTD: ', num2str(ICSFit(4),3), '\nOrient.: ' num2str(ICSFit(2),3) ]);
   set(handles.AnalysisResultsTxt,'String',ICSResults);
   set(handles.AnalysisResultsTxt, 'Enable', 'on')
   handles.ICSResults = ICSFit;
   handles.CurMeas.ICS = ICSFit; % Also save ICS Fit within current measurement
   set(handles.ICSEnable,'Value',1);
end

%% 8 Window Menu Functions
% --- File
function file_Callback(hObject, eventdata, handles)
% hObject    handle to file (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
end
% --- Help
function help_Callback(hObject, eventdata, handles)
% hObject    handle to help (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
end
% --- About
function about_Callback(hObject, eventdata, handles)
    % hObject    handle to about (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    structure with handles and user data (see GUIDATA)
    doc IAGUI
end
% --- Print
function print_Callback(hObject, eventdata, handles)
    % hObject    handle to print (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    structure with handles and user data (see GUIDATA)
    printdlg(handles.figure1)
end
% --- Close
function close_Callback(hObject, eventdata, handles)
    % hObject    handle to close (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    structure with handles and user data (see GUIDATA)
    selection = questdlg(['Close ' get(handles.figure1,'Name') '?'],...
                         ['Close ' get(handles.figure1,'Name') '...'],...
                         'Yes','No','Yes');
    if strcmp(selection,'No')
        return;
    end
    delete(handles.figure1)
end

%% 9 Processing Image Display
%
% --- Deal with color selection
function grpColor_SelectionChangeFcn(hObject, eventdata, handles)
    % hObject    handle to the selected object in grpColor 
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    structure with handles and user data (see GUIDATA)
%    CurentColor = get(handles.hObject,'Tag')
    switch get(hObject,'Tag')
        case 'rdoNone'
            CurrentColor = 1;
        case 'rdoRed'
            CurrentColor = 2;
        case 'rdoPink'
            CurrentColor = 3;
        case 'rdoBlue'
            CurrentColor = 4;
        case 'rdoTeal'
            CurrentColor = 5;
        case 'rdoGreen'
            CurrentColor = 6;
        case 'rdoYellow'
            CurrentColor = 7;
        case 'rdoWhite'
            CurrentColor = 8;
    end
    handles.ChanCol(get(handles.lstDisplayChan,'Value')) = CurrentColor;
    handles = RefreshDisplayImg(handles);
    guidata(handles.figure1,handles);
end
% --- Activate color for channel in analyze window 
function lstDisplayChan_Callback(hObject, eventdata, handles)
        switch handles.ChanCol(get(hObject,'Value'))
            case 1
                set(handles.rdoNone,'Value',1);
            case 2
                set(handles.rdoRed,'Value',1);
            case 3
                set(handles.rdoPink,'Value',1);
            case 4
                set(handles.rdoBlue,'Value',1);
            case 5
                set(handles.rdoTeal,'Value',1);    
            case 6
                set(handles.rdoGreen,'Value',1);
            case 7
                set(handles.rdoYellow,'Value',1);
            case 8
                set(handles.rdoWhite,'Value',1);
        end
        set(handles.edtChanIntensity,'String',num2str(handles.ChanIntensity(get(hObject,'Value'))));

    guidata(handles.figure1,handles);
end
function lstDisplayChan_CreateFcn(hObject, eventdata, handles)
    % hObject    handle to lstDisplayChan (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    empty - handles not created until after all CreateFcns called

    % Hint: listbox controls usually have a white background on Windows.
    %       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end
end
% --- Change relatice channel intensity in display only
function edtChanIntensity_Callback(hObject, eventdata, handles)
    handles.ChanIntensity(get(handles.lstDisplayChan,'Value')) =...
        str2double(get(handles.edtChanIntensity,'String'));
    handles = RefreshDisplayImg(handles);
    guidata(handles.figure1,handles);
end
function edtChanIntensity_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtChanIntensity (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end
% --- SUPPORT Function; Mix selected display channels to create image that
% can be displayed in analysis window; adds scale bar; 
% does not add vector display, doe snot display calculated image
% used in conjunciton with Refresh Display Image
function DisplayImg = GetDisplayImg(handles)
    [Width,Height] =size(handles.ImgChannel{1,1});
    DisplayImg = double(zeros(Width,Height,3));

    % adapt to 16 or 8 bit data
    % assuming all channels are one or the other
    switch class(handles.ImgChannel{1,1})
        case 'uint8'
            scl=255;
        case 'uint16'
            scl=65535;
        otherwise
            warning('unsupported bit depth')
            scl=1;
    end
    
    %%
    % RGB Colormixer, can build up image based on any number of channels
    % and colors associated to that channel.
    for k=1:3
        for j=1:length(handles.ImgChannel(1,:))
            DisplayImg(:,:,k) = scl - 1./scl.*(scl-DisplayImg(:,:,k)).*(scl-double(handles.ImgChannel{handles.CurImgNo,j})... 
                                                                     .*handles.ColorDef(handles.ChanCol(j),k)...
                                                                     .*handles.ChanIntensity(j));
        end
    end
    DisplayImg = DisplayImg./scl;

    %%
    % Add scale bar
    if (get(handles.chkShow200um,'Value')==1)
        CorrFac = str2double(get(handles.edt200um,'String'));
        PixSpace = str2double(get(handles.edtPixSpace,'String'));
        % LineSize = int16(50 / handles.LSMinf.ScanInfo.SAMPLE_SPACING*CorrFac);
        LineSize = int16(50 / PixSpace*CorrFac);
        Transparency = str2double(get(handles.edtBarTransp,'String'));
        if Transparency > 1
            Transparency =1;
        elseif Transparency < 0
            Transparency = 0;
        end
       if (get(handles.rdoBarWhite,'Value') ==1)
           % white scale bar
           for j=1:3
                DisplayImg(15:20,15:15+LineSize,j) = 1 - Transparency + ( DisplayImg(15:20,15:15+LineSize,j) * Transparency );
           end
       else
           % black scale bar
           for j=1:3
                DisplayImg(15:20,15:15+LineSize,j) = DisplayImg(15:20,15:15+LineSize,j) * Transparency;
           end
       end
    end
    
    %%
    % Add other information onto image
    % None implemented yet
    
end
% --- SUPPORT Function: Refresh dispplay in main analysis window 
% calls getdisplayimage (which adds scale bar)
% update vector/quiver plot
% first check existing plot handles, then delete them, then rebuild them
function handles = RefreshDisplayImg(handles)
        displayimage = GetDisplayImg(handles);
        axes(handles.procimg);
        TempHandlesVectors = handles.Vectors;
        TempHandlesICSResults = handles.ICSResults;
        TempHandlesVessel = handles.VesselLineHandle;
        TempHandlesProfile = handles.ProfileLineHandle;
        TempHandlesROI = handles.ROILineHandle;        
        % clear processing image handles
        handles = cla_procimg(handles);
        % rebuild processing image handle
        handles.DisplayImgHandle = imshow(displayimage);
        hold on;
        if (~isempty(TempHandlesVectors))
            delete(handles.Vectors);
            handles.Vectors=quiver(handles.VectorField.x,handles.VectorField.y,handles.VectorField.u,handles.VectorField.v,'r-');
            if (get(handles.VectorEnable,'Value')==1)
                set(handles.Vectors,'Visible','on');
            end
        end
        if (~isempty(TempHandlesICSResults))
            delete(handles.ICSResults);
            handles.ICSResults=TempHandlesICSResults;
            ICSResults = sprintf(['Ampl.: ', num2str(ICSFit(1),3), ' Offs.: ', ...
                         num2str(ICSFit(5),3), '\nMSTD: ', num2str(ICSFit(3),3), ...
                         ' mSTD: ', num2str(ICSFit(4),3), '\nOrient.: ' num2str(ICSFit(2),3) ]);
            set(handles.AnalysisResultsTxt,'String',ICSResults);
            if (get(handles.ICSEnable,'Value')==1)
                set(handles.AnalysisResultsTxt, 'Enable', 'on')
            end
        end
        if (~isempty(TempHandlesProfile))
            delete(handles.ProfileLineHandle);
            handles.ProfileLineHandle = plot(handles.CurMeas.Profile.X,handles.CurMeas.Profile.Y,'-y');
        end
        if (~isempty(TempHandlesVessel))
            delete(handles.VesselLineHandle);
            handles.VesselLineHandle = plot(handles.CurMeas.Vessel.X,handles.CurMeas.Vessel.Y,'-c');
        end
        if (~isempty(TempHandlesROI))
            delete(handles.ROILineHandle);
            handles.ROILineHandle = plot(handles.CurMeas.ROIx,handles.CurMeas.ROIy,'-g');
        end
end

%% 10 Image Filter & Histogram
% This will affect data in further analysis
% ------ Histogram
%
% --- Create intensity histogram
function popHistBackChan_Callback(hObject, eventdata, handles)
  %Plot the intensity histogram
   axes(handles.ChannelHist);
   cla; set(gca,'FontSize', 8); 
   [counts,x] = imhist(handles.ImgChannel{handles.CurImgNo,get(handles.popHistBackChan,'Value')});  
   plot(x,counts,'-');
   %set(h,'MarkerFaceColor','white')
   h=title(['Img. ', num2str(handles.CurImgNo), ', Chan. ', num2str(get(handles.popHistBackChan,'Value')),' Histogram']);   set(h,'FontSize', 8);
   DataMax = max(max(handles.ImgChannel{handles.CurImgNo,get(handles.popHistBackChan,'Value')}));
   DataMin = min(min(handles.ImgChannel{handles.CurImgNo,get(handles.popHistBackChan,'Value')}));
   set(handles.txtMaxData,'String',['Max: ',num2str(DataMax)]);
   set(handles.txtMinData,'String',['Min: ',num2str(DataMin)]);

   % adapt to bit depth
   switch class(handles.ImgChannel{handles.CurImgNo,get(handles.popHistBackChan,'Value')})
        case 'uint8'
            scl=255;
        case 'uint16'
            scl=65535;
        otherwise
            warning('unsupported bit depth')
            scl=255;
   end
   xlim([0 scl]);

end
function popHistBackChan_CreateFcn(hObject, eventdata, handles)
    % hObject    handle to popHistBackChan (see GCBO)
    % eventdata  reserved - to be defined in a future version of MATLAB
    % handles    empty - handles not created until after all CreateFcns called

    % Hint: popupmenu controls usually have a white background on Windows.
    %       See ISPC and COMPUTER.
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end
end
% --- Wiener denoising
% 
% --- Apply Wiener filter update current histogram channel.
function btnWiener_Callback(hObject, eventdata, handles)
% hObject    handle to btnWiener (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    FilterSize=str2num(get(handles.edtWiener,'String'));
    handles.ImgChannel{handles.CurImgNo,get(handles.popHistBackChan,'Value')} = wiener2(...
            handles.ImgChannel{handles.CurImgNo,get(handles.popHistBackChan,'Value')},...
            [FilterSize FilterSize]);
        
    handles = RefreshDisplayImg(handles);
        
    guidata(handles.figure1,handles);
    popHistBackChan_Callback(handles.popHistBackChan, [], handles)
end
% --- Wiener size
function edtWiener_Callback(hObject, eventdata, handles)
% hObject    handle to edtWiener (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtWiener as text
%        str2double(get(hObject,'String')) returns contents of edtWiener as a double
end
function edtWiener_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtWiener (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end
% --- Activate Image Constrast Pannel.
function btnImConstrast_Callback(hObject, eventdata, handles)
CurImgNo = handles.CurImgNo;
CurChanNo = get(handles.popHistBackChan,'Value');
% FigH = figure; 
% set(FigH,'MenuBar','none',...
%          'ToolBar','none',...
%          'Name', ['Contrast Adjust for Channel ',num2str(CurChanNo)],...
%          'Position', [200 200 800 1000]);
% AxH = axes();
% %axes(AxH);
% ImgH = imshow(handles.ImgChannel{CurImgNo,CurChanNo});
% imcontrast(ImgH);
[ResImg FigHandle]= spxContrAdjst(handles.ImgChannel{CurImgNo,CurChanNo});
delete(FigHandle);

handles.ImgChannel{CurImgNo,CurChanNo} = ResImg;
handles = RefreshDisplayImg(handles);
        
guidata(handles.figure1,handles);
popHistBackChan_Callback(handles.popHistBackChan, [], handles)
end
% --- Modifications
% 
% --- Reload current channel.
function btnResetChan_Callback(hObject, eventdata, handles)
% hObject    handle to btnResetChan (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    handles.ImgChannel{handles.CurImgNo,get(handles.popHistBackChan,'Value')} =...
    handles.OrigImgChannel{handles.CurImgNo,get(handles.popHistBackChan,'Value')};
    handles = RefreshDisplayImg(handles);    
        
    guidata(handles.figure1,handles);
    popHistBackChan_Callback(handles.popHistBackChan, [], handles);
end
% --- Reload all channels.
function btnResetImg_Callback(hObject, eventdata, handles)
% hObject    handle to btnResetImg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    handles.ImgChannel = handles.OrigImgChannel;
    handles = RefreshDisplayImg(handles);    
     
    guidata(handles.figure1,handles);
    popHistBackChan_Callback(handles.popHistBackChan, [], handles);
end

%% 11 Image Scale Bar
% --- Change scale bar length with relative factor
% scale bar is added in display function not to original data
function edt200um_Callback(hObject, eventdata, handles)
    if (get(handles.chkShow200um,'Value')==1)
        handles = RefreshDisplayImg(handles);
        guidata(handles.figure1,handles);
    end
end
function edt200um_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edt200um (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

end
% --- Place checkmark on chkShow200um
function chkShow200um_Callback(hObject, eventdata, handles)
    if (get(handles.chkShow200um,'Value')==1)
        handles = RefreshDisplayImg(handles);
        guidata(handles.figure1,handles);
    end
end
% --- Set scale manually
function edtPixSpace_Callback(hObject, eventdata, handles)
% hObject    handle to edtPixSpace (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtPixSpace as text
%        str2double(get(hObject,'String')) returns contents of edtPixSpace as a double
    if (get(handles.chkShow200um,'Value')==1)
        handles = RefreshDisplayImg(handles);
        guidata(handles.figure1,handles);
    end
end
function edtPixSpace_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtPixSpace (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end
% --- Modify transparency of scalebar
function edtBarTransp_Callback(hObject, eventdata, handles)
    if (get(handles.chkShow200um,'Value')==1)
        handles = RefreshDisplayImg(handles);
        guidata(handles.figure1,handles);
    end
end
function edtBarTransp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtBarTransp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end
% --- White Scalebar.
function rdoBarWhite_Callback(hObject, eventdata, handles)
    if (get(hObject,'Value') == 1)
        set(handles.rdoBarBlack,'Value',0);
    end
    if (get(handles.chkShow200um,'Value')==1)
        handles = RefreshDisplayImg(handles);
        guidata(handles.figure1,handles);
    end
end
% --- Black Scalebar.
function rdoBarBlack_Callback(hObject, eventdata, handles)
    if (get(hObject,'Value') == 1)
        set(handles.rdoBarWhite,'Value',0);
    end
    if (get(handles.chkShow200um,'Value')==1)
        handles = RefreshDisplayImg(handles);
        guidata(handles.figure1,handles);
    end
end

%% 12 Output
% --- Save Image
function btnSaveImage_Callback(hObject, eventdata, handles)
% 
[SizeR SizeC] = size(handles.ImgChannel{1,1});                       
displayimage = GetDisplayImg(handles);
h=figure('Position',[5,5,SizeR,SizeC]);
imshow(displayimage);

    %% add the Vector graphics
    if (~isempty(handles.Vectors))
        hold on;
        if (get(handles.VectorEnable,'Value')==1) % only show vectors if vector show = on
             quiver(handles.VectorField.x,handles.VectorField.y,handles.VectorField.u,handles.VectorField.v,'r-');
        end
    end
    
    %% Add Other Markings
    if (~isempty(handles.ProfileLineHandle))
        plot(handles.CurMeas.Profile.X,handles.CurMeas.Profile.Y,'-y');
    end
    if (~isempty(handles.VesselLineHandle))
        plot(handles.CurMeas.Vessel.X,handles.CurMeas.Vessel.Y,'-c');
    end
    if (~isempty(handles.ROILineHandle))
       plot(handles.CurMeas.ROIx,handles.CurMeas.ROIy,'-g');
    end
        
 hx=get(h,'CurrentAxes');

 set(h,'PaperUnits','points',...
           'Units','pixels',...
           'Position',[5 5 SizeR SizeC],...
            ...%'MenuBar','none',...
            'WindowStyle','normal',...
            'PaperSize',[SizeR SizeC]);
 set(hx,'Units','pixels','Position',[1 1 SizeR SizeC]);  
end

%% 13 Matlab Miscalleneous
%
% --- Executes when figure1 is resized.
function figure1_ResizeFcn(hObject, eventdata, handles)
% hObject    handle to uipanel7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
end
% --- Executes during object creation, after setting all properties.
function figure1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called 
end
% --- Executes when uipanel7 is resized.
function uipanel7_ResizeFcn(hObject, eventdata, handles)
% hObject    handle to uipanel7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
end
% --- 
function edit5_Callback(hObject, eventdata, handles)
end
function edit5_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end
end
function edit6_Callback(hObject, eventdata, handles)
end
function edit6_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end
end
function edit7_Callback(hObject, eventdata, handles)
end
function edit7_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end
end
function edit8_Callback(hObject, eventdata, handles)
end
function edit8_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end
end
function edit9_Callback(hObject, eventdata, handles)
end
function edit9_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end
end
function edit10_Callback(hObject, eventdata, handles)
end
function edit10_CreateFcn(hObject, eventdata, handles)
    if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
        set(hObject,'BackgroundColor','white');
    end
end
% --- Executes on button press in pushbutton34.
function pushbutton34_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton34 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
end
% --- Executes on button press in pushbutton35.
function pushbutton35_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton35 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
end
% --- Executes on button press in pushbutton36.
function pushbutton36_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton36 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
end
%
function edit18_Callback(hObject, eventdata, handles)
% hObject    handle to crop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of crop as text
%        str2double(get(hObject,'String')) returns contents of crop as a double
%
end
% --- Executes during object creation, after setting all properties.
function crop_CreateFcn(hObject, eventdata, handles)
% hObject    handle to crop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end


