function [a,ICS2DCorr,ICS2DCorrCrop] = ICS2Di(imageSeries,varargin)
% [a,ICS2DCorr,ICS2DCorrCrop] = ICS2Di(imageseries, pixelsize, cropto)
% 2D correlation spectroscopy.
%
% Input: Image Stack
% Output:
% ACF: ('ICS2DCorr'),
% Ccropped ACF ('ICS2DCorrCrop') 
% Fit Paramter 'a' 
% a(1) is the amplitude, 
% a(2) is the orientation, 
% a(3)& a(4) are the standard deviation major and minor,
% a(5) is the offset 
% a(6),a(7) is the center offset i.e. (x0,y0).
%
% Description:
% Auto Correlation Function ACF is calcualted using Matlab 'corrfunc' routine. 
% Optional 3-D plot. 
% ACF is then cropped with'autocrop' routine. 
% 2D Gaussian fit of ACF gaussfit routine.
% Optional 'plotgaussfit' 

global dbg
if nargin <1
    error('Need input data')
elseif nargin <=1
    %Assuming a pixel size of 1
    pxsize = 1;
    cropto=12;
    plt=0;
elseif nargin <=2
    pxsize = varargin{1};
    cropto=12;
    plt=0;
elseif nargin <=3
    pxsize = varargin{1};
    cropto= varargin{2};
elseif nargin <=4
    pxsize = varargin{1};
    cropto= varargin{2};
    plt=varargin{3};
end

% Autocorrelation function.
ICS2DCorr = corrfunc(imageSeries);

%the correlation function is plotted 
if dbg
    figure (99);
    s=surf(ICS2DCorr(:,:,1));
    axis tight
    colormap(jet)
    xlabel('\eta','FontSize',12)
    ylabel('\xi','FontSize',12)
    zlabel('r(\xi,\eta)','FontSize',12)
    set(s,'LineStyle','none')
    title('Spatial Autocorrelation Function')
end

%The ACF is cropped using the 'autocrop' routine
% Why is this 12 here? This sets amount of autocrop
ICS2DCorrCrop = autocrop(ICS2DCorr,cropto);

%the Cropped ACF is plotted
if dbg
    figure(100);
    s=surf(ICS2DCorrCrop(:,:,1));  
    axis tight
    colormap(jet)
    xlabel('\eta','FontSize',12)
    ylabel('\xi','FontSize',12)
    zlabel('r(\xi,\eta)','FontSize',12)
    set(s,'LineStyle','none')
    title('Cropped Spatial Autocorrelation Function')
end

%The cropped ACF is then fit to a 2-D Gaussian function using the
%'gaussfit' routine
%tic
% replace pxsize with one and then scale later
a  = gaussfit(ICS2DCorrCrop,'2d',1,'y');
% adjust for pxsize
a(3)= a(3)*pxsize;
a(4)= a(4)*pxsize;
%toc

%The Gaussian fit is then plotted and checked for consistency with the
%cropped ACF using the 'plotgaussfit' routine
if plt
    plotgaussfit(a(1,1:7),ICS2DCorrCrop(:,:,1),pxsize,'y');
end

%particlesPerBeamArea = 1/(mean(a(:,1)))
%beamArea = pi*mean(a(:,2))*mean(a(:,3))
%density = particlesPerBeamArea/beamArea

