%Function [imdata] = bw(img,filename)
%Function to convert the image to a black and white image and crop the
%central m/2*n/2 portion of the image as the region of interest. Here img
%is the data values of the image as a matrix and filename is the name of
%the file to which the image is to be written

function [imdata] = bw(img,filename)
%s = imread(filename);
data = im2bw(img,graythresh(img));
s = size(img);
%for i = 321:576
 %   for j = 471:726
  %      imdata((i-320),(j-470)) = data(i,j);
   % end
%end
imdata = imcrop(data,[s(1)/4 s(2)/4 ((s(1)/2)-1) ((s(2)/2)-1)]);
imwrite(imdata,filename);
end
  
