function [a, res] = gaussfit(corr,type,pixelsize,whitenoise,varargin)
% [a, res] = gaussfit(corr,type,pixelsize,whitenoise)
% corr:         cropped image (correlation)
% type:         2d or time
% pixelsize:    scale factor, use 1
% whitenoise:   y or no, y eliminates center of ACF/image for fit
%
% a: fit parameters
%    a(1)= amplitude
%    a(2)= theta
%    a(3)= sigmax
%    a(4)= sigmay
%    a(5)= offset
%    a(6)= zero_x
%    a(7)= zero_y
%
% res: residual
%
% Could use more work in cleaning up and intial guess calculation

if size(varargin,2) > 0
    astart=varargin{1};
end


% This might take some time: Change mousepointer
set(gcbf,'pointer','watch');


[X,Y] = meshgrid(-((size(corr,2)-1)/2)*pixelsize:pixelsize:((size(corr,2)-1)/2)*pixelsize,-((size(corr,1)-1)/2)*pixelsize:pixelsize:(size(corr,1)-1)/2*pixelsize);
% Need to combine variables for fitting routine because can only pass one
grid = [X Y];

% --------------------------------------------
% Prepare Optimization
% --------------------------------------------

% Weights guess
weights = ones(size(corr));
% If there's whitenoise, 2 highest values (NB this might be more than
% two points!) in corr func are set to zero, and given no weight in the fit
if strcmp(whitenoise,'y')
    if strcmp('2d',type)
       for j=1:2
            i = find(ismember(corr(:,:,:),max(max(corr(:,:,:)))));
            ZerChan = i;
            corr(i) = [0];
            weights(i) = 0;
       end
    end
    if strcmp(type,'time')
       for j=1:2
            i = find(ismember(corr(:,:,1),max(max(corr(:,:,1)))));
            corr(i) = [0];
            weights(i) = 0;
       end
    end    
end

% Offset guess
y0 = zeros(size(corr,3),1);
% Amplitude guess
g0 = max(max(corr)); g0 = squeeze(g0);

% Sigma guess
%
wguess = zeros(size(corr,3),1);
for i=1:size(corr,3)
   [Wy, Wx] = find(ismember(abs((corr(:,:,i)/g0(i) - exp(-1))),min(min(abs(corr(:,:,i)/g0(i) - exp(-1))))));
   Wx = mod(Wx,size(corr,2));
   % wguess(i) = mean(( (Wx - X0(i)).^2  + (Wy - Y0(i)).^2   ).^(1/2))*pixelsize;
   wguess(i) = mean(( (Wx).^2  + (Wy).^2   ).^(1/2))*pixelsize;
end
wguess=wguess/4;
% wguess = 0.4*ones(size(g0));


% Fit options
% increased from 0.5 *1e4 to 0.5 * 1e6
curvefitoptions = optimset('Display','on', 'TolFun',nanmean(nanmean(corr))/(0.5*1e12),'TolX',(grid(1,2)-grid(1,1))/(0.5*1e6));
%curvefitoptions = optimset('Display','off');
   
% Fits each corr func separately
if strcmp('2d',type)
    % New
    %    a(1)= amplitude
    %    a(2)= theta
    %    a(3)= sigmax
    %    a(4)= sigmay
    %    a(5)= offset
    %    a(6)= zero_x
    %    a(7)= zero_y

    % set start points for all image planes
    for i=1:size(corr,3)

        % Orientation (Theta) guess:
        %
        % First Attempt
        % Smoothing the ACF to produce a better estimate of the orientation
        %  corr2 = corr(:,:,i);
        % dim = size(corr2);
        % corrsmooth = smooth(corr2);
        % corr1 = reshape(corrsmooth,dim(1),dim(2));      
        % [gx,gy]=gradient(corr1);
        % f=atan(gx./gy);
        % am=sqrt(gx.^2+gy.^2);
        % f=asin(gx./am);
        % mi=min(min(corr1));
        % ma=max(max(corr1));
        % lt=mi+(ma-mi)*0.1;
        % ut=mi+(ma-mi)*0.9;
        % msk=(am>lt&am<ut);
        % a0xy(2)= mean(f(msk));
        %
        % Currenlty used approach: based on gradient and mask
        [gx,gy]=gradient(corr(:,:,i)); 
        f=atan(gx./gy);
        am=sqrt(gx.^2+gy.^2);
        mi=min(min(corr(:,:,1)));
        ma=max(max(corr(:,:,1)));
        lt=mi+(ma-mi)*0.1;
        ut=mi+(ma-mi)*0.9;
        msk=(am>lt&am<ut&isfinite(f)); % need to make sure NaN and Inf are not considered
        a0xy(2)= mean(f(msk)); % Angle
        if isnan(a0xy(2)); a0xy(2)=0; end;
        
        a0xy(1) = g0(i) ;    % Amplitude
        a0xy(3) = wguess(i); % SigmaX
        a0xy(4) = wguess(i); % SigmaY
        a0xy(5) = y0(i);     % Offset
        
        % Not used at this time
        a0xy(6) = 0.5; %initguess(i,4); % zero_X
        a0xy(7) = 0.5; %initguess(i,5); % zero_Y
                   
        % Upper and Lower Boudnaries
        % lb = [0 -pi/2  0 0 0 -1 -1];
        % ub = [Inf pi/2 Inf Inf Inf 1 1];
        lb = [0 -1.7453 0 0 0 -500 -500 ];
        ub = [Inf 1.7453 Inf Inf Inf 500 500];

        if exist('astart');
            a0xy=astart;  
            curvefitoptions.TolFun=curvefitoptions.TolFun/1000;
            curvefitoptions.TolX=curvefitoptions.TolX/1000;
        end
            
        [a(i,:),res(i),RESIDUAL,EXITFLAG,OUTPUT,LAMBDA] = lsqcurvefit(@gauss2dwxy,a0xy,grid,corr(:,:,i).*weights(:,:,i),lb,ub,curvefitoptions,weights(:,:,i));
        
        % Make sure minor axis is smaller than major axis,
        % Flip angle if necessary
        % adegrees = a(2)*180/pi;
        if(a(i,3)<a(i,4))
            a(i,2) = a(2)+(pi/2);
            temp = a(i,3) ;
            a(i,3) = a(i,4);
            a(i,4) = temp;
        end % flipping axis

    end % for stack
end % if 2d

if strcmp('time',type)
    % Original time code, no generalized Gaussian version
    %
    % Was previously in original code
    %    a(1)= amplitude
    %    a(2)= sigmax
    %    a(3)= sigmay
    %    a(4)= offest
    %    a(5)= zero_x
    %    a(6)= zero_y
    %
    
    % Sets curve fit options, and sets lower bounds for amplitude and beam
    % radius to zero
    lb = [0 0 -1 min(min(grid)) min(min(grid))];
    ub = [];
    [Y0, X0] = find(ismember(corr,max(max(corr))),size(corr,3));
    X0 = mod(X0,size(corr,2));
    %EvilX0 and Y0 are where remainder from mod was zero -- these are set to the "max" (ie size) of the corr
    EvilX0 = find(ismember(X0,0));
    X0(EvilX0) = size(corr,2);
    % Converts from matrix index to LOCATION in pixelsize units
    % Pretty strange code
    for i=1:size(corr,3)
        X0(i) = X(1,X0(i)); 
    end
    for i=1:size(corr,3)
        Y0(i) = Y(Y0(i),1);  
    end
    
    % Initial guess
    initguess = [g0 wguess y0 X0 Y0];

    for i=1:size(corr,3)
        a0 = initguess(i,:);
        [a(i,:),res(i),RESIDUAL,EXITFLAG,OUTPUT,LAMBDA] = lsqcurvefit(@gauss2d,a0,grid,corr(:,:,i).*weights(:,:,i),lb,ub,curvefitoptions,weights(:,:,i));
    end % for stack
end % if time

% Flipp point back to normal arrow
set(gcbf,'pointer','arrow');