function F = gauss2dwxy(a,data,weights);
% F = gauss2dwxy(a,data,weights);
% a(1)=amplitude; a(2)=angle; a(3)=sigmax; a(4)=sigmay; a(5)=offset;
% a(6)=xoffset; a(7)=yoffset;
% data
% weights
% F
% 
% Used by the curve fitter to calculate values for a 2d gaussian
% recreate grid from single input variable

l=size(data,2);
X = data(:,1:l/2);
Y = data(:,l/2+1:end);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% generalized gaussian fitting
% check wikipedia
theta = a(2);
sigma_x = a(3);
sigma_y = a(4); 
k = cos(theta)^2/2/sigma_x^2 + sin(theta)^2/2/sigma_y^2;
l = -sin(2*theta)/4/sigma_x^2 + sin(2*theta)/4/sigma_y^2 ;
m = sin(theta)^2/2/sigma_x^2 + cos(theta)^2/2/sigma_y^2;

F =    (a(1)*exp( - (k*((X-a(6)).^2) + 2*l*(X-a(6)).*(Y-a(7)) + m*((Y-a(7)).^2))) + a(5)).*weights;
%F =    (a(1)*exp( - (k*((X-0.5).^2) + 2*l*(X-0.5).*(Y-0.5) + m*((Y-0.5).^2))) + a(5)).*weights;

%%%%%%
% Version that would include the origin offset
%F =    (a(1)*exp( - (k*((X-a(6)).^2) + 2*l*(X-a(6)).*(Y-a(7)) + m*((Y-a(7)).^2))) + a(5)).*weights;

% gauss fit 2d wt xy F = (a(1)*exp(-((X-a(5)).^2/(1*(a(2)^2))+(Y-a(6)).^2/(1*(a(3)^2)))   ) + a(4)).*weights;
% gauss fit 2d no xy F = (a(1)*exp(-((X-a(4)).^2+(Y-a(5)).^2)/(a(2)^2)) + a(3)).*weights;
%
%F = (a(1)*exp(    -((data(:,1:l/2)-a(5)).^2/(a(2)^2)+(data(:,l/2+1:end)-a(6)).^2/(a(3)^2))   ) + a(4)).*weights;
%F = a(1)*exp(-(((a(x-a(5)).^2))+(2*b*(x-a(5))(y-a(6)))+(c(y-a(6)).^2)));
