function im = invertimg(im)
% im=invert(im)
% simple im=1-im

% adapt to bit depth
switch class(im)
   case 'uint8'
       scl=255; % 2^8-1
   case 'uint16'
       scl=65535; % 2^16-1
   otherwise
       warning('unsupported bit depth')
       scl=max(im(:));
end
im=scl-im;
end
