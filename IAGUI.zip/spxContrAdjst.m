function varargout = spxContrAdjst(varargin)
% SPXCONTRADJST M-file for spxContrAdjst.fig
%      SPXCONTRADJST, by itself, creates a new SPXCONTRADJST or raises the existing
%      singleton*.
%
%      H = SPXCONTRADJST returns the handle to a new SPXCONTRADJST or the handle to
%      the existing singleton*.
%
%      SPXCONTRADJST('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SPXCONTRADJST.M with the given input arguments.
%
%      SPXCONTRADJST('Property','Value',...) creates a new SPXCONTRADJST or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before spxContrAdjst_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to spxContrAdjst_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help spxContrAdjst

% Last Modified by GUIDE v2.5 17-Oct-2007 14:37:31

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @spxContrAdjst_OpeningFcn, ...
                   'gui_OutputFcn',  @spxContrAdjst_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end


% End initialization code - DO NOT EDIT

% --- Executes just before spxContrAdjst is made visible.
function spxContrAdjst_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to spxContrAdjst (see VARARGIN)

% Choose default command line output for spxContrAdjst
handles.hObject = hObject;
handles.DispImg = varargin{1};
axes(handles.axDispImg);
handles.DispImHandle = imshow(handles.DispImg);
imcontrast(handles.DispImHandle);
handles.output = getimage(handles.axDispImg); %default output

% Update handles structure
guidata(hObject, handles);
set(handles.btnExit,'Enable','on');

% UIWAIT makes spxContrAdjst wait for user response (see UIRESUME)
 uiwait(handles.figure1);
% guidata(handles.figure1, handles);


% --- Outputs from this function are returned to the command line.
function varargout = spxContrAdjst_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Get default command line output from handles structure
if ~isempty(handles);
varargout(1) = {handles.output};
varargout(2) = {handles.figure1};
end

% --- Executes when user attempts to close figure1.
function varargout = figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%size(getimage(handles.axDispImg))
% Hint: delete(hObject) closes the figure
handles.output = handles.DispImg;
guidata(handles.figure1, handles);
uiresume(handles.figure1);

% --- Executes on button press in btnExport.
function btnExport_Callback(hObject, eventdata, handles)
% hObject    handle to btnExport (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.output = getimage(handles.axDispImg);
guidata(handles.figure1, handles);
uiresume(handles.figure1);
%delete(handles.figure1);


% --- Executes on button press in btnExit.
function btnExit_Callback(hObject, eventdata, handles)
% hObject    handle to btnExit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.output = handles.DispImg;
guidata(handles.figure1, handles);
uiresume(handles.figure1);
%delete(handles.figure1);delete(handles.figure1)


